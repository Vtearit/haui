<?php

namespace App\Shared;

use Illuminate\Support\Str;

trait Sortable
{
   public function scopeSort($query, $params)
   {
      // check Model has sortable property
      if (empty($this->sortable) || !is_array($this->sortable)) {
         return $query;
      }

      // result need to be sorted
      if (!array_key_exists('sort', $params)) {
         return $query;
      }

      $sort = $params['sort'];

      if (!in_array($sort, $this->sortable)) {
         return $query;
      }

      if (!array_key_exists('dir', $params)) {
         return $query->orderByAsc($sort);
      }

      $dir = $params['dir'];

      $method = 'sortBy' . Str::studly($sort);

      if (method_exists($this, $method)) {
         return $this->{$method}($query, $dir);
      }

      $query->orderBy($sort, $dir);
      return $query;
   }
}
