<?php

namespace App\Shared;

use Illuminate\Support\Str;

use function PHPUnit\Framework\isNull;

trait Filterable
{
   public function scopeFilter($query, $params)
   {
      foreach ($params as $field => $value) {
         $method = 'filter' . Str::studly($field);

         if ($value === '') {
            continue;
         }

         if (method_exists($this, $method)) {
            $this->{$method}($query, $value);
            continue;
         }

         if (empty($this->filterable) || !is_array($this->filterable)) {
            continue;
         }

         if (in_array($field, $this->filterable)) {

            if (str_ends_with($field, 'd_at')) {
               $query->whereDate($field, $value);
               continue;
            }
            if (is_string($value)) {
               $query->where($this->table . '.' . $field, 'LIKE', $value . "%");
               continue;
            }

            $query->where($this->table . '.' . $field, $value);
         }
      }

      return $query;
   }
}
