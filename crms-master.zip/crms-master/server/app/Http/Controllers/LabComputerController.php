<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Computer;
use App\Models\Lab;
use App\Http\Resources\MyCollection;

class LabComputerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($lab_id)
    {
        $params = request()->all();
        $per_page = intval(request()->input('per_page', 10));

        $lab = Lab::find($lab_id);

        if (request()->has('ids')) {
            return $lab->computers()->pluck('id')->toArray();
        }

        return new MyCollection(
            $lab->computers()
                ->filter($params)
                ->sort($params)
                ->paginate($per_page)
        );
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store($lab_id, Request $request)
    {
        // clear
        Lab::find($lab_id)->computers()->update(['lab_id' => null]);


        $id = $request->all();
        return Computer::whereIn('id', $id)->update(['lab_id' => $lab_id]);
    }
}
