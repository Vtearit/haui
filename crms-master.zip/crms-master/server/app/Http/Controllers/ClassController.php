<?php

namespace App\Http\Controllers;

use App\Exceptions\ResponseException;
use Illuminate\Http\Request;
use App\Http\Resources\MyCollection;
use App\Models\TheClass;


class ClassController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $params = request()->all();
        if (request()->has('ids')) {
            return TheClass::pluck('id')->toArray();
        }
        $per_page = intval(request()->input('per_page', 10));

        $results = TheClass::filter($params)->sort($params)->paginate($per_page);

        return new MyCollection($results);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try {
            $params = $request->all();
            return TheClass::create($params);
        } catch (\PDOException $e) {
            return response()->json([
                "id" => "Id is already existed",
            ], 409);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return TheClass::find($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        try {
            $c = TheClass::find($id);

            if (!$c) {
                throw new ResponseException("Not found", 404, 'id');
            }

            return $c->update($request->all());
        } catch (ResponseException $e) {
            return $e->getResponse();
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return TheClass::destroy($id);
    }
}
