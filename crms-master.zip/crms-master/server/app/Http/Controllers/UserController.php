<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Http\Resources\MyCollection;
use App\Exceptions\ResponseException;


class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $params = request()->all();
        if (request()->has('ids')) {
            return User::pluck('id')->toArray();
        }
        $per_page = intval(request()->input('per_page', 10));

        $results = User::filter($params)->sort($params)->paginate($per_page);

        return new MyCollection($results);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try {
            return User::create($request->all());
        } catch (\PDOException $e) {
            if (preg_match("/Duplicate entry .+ for key '(.+)'/", $e->getMessage(), $keys)) {

                $error_key = $keys[1] == 'PRIMARY' ? 'id' : $keys[1];

                return response()->json([
                    $error_key => $error_key . " is already existed"
                ], 409);
            } else {
                throw $e;
            }
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user = User::find($id);

        if ($user) {
            $user->payedSchedules();
        }
        return $user;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        try {
            $user = User::find($id);

            if (!$user) {
                throw new ResponseException("Not found", 404, 'id');
            }

            return $user->update($request->all());
        } catch (\PDOException $e) {
            if (preg_match("/Duplicate entry .+ for key '(.+)'/", $e->getMessage(), $keys)) {

                $error_key = $keys[1] == 'PRIMARY' ? 'id' : $keys[1];

                return response()->json([
                    $error_key => $error_key . " is already existed"
                ], 409);
            } else {
                throw $e;
            }
        } catch (ResponseException $e) {
            return $e->getResponse();
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return User::destroy($id);
    }
}
