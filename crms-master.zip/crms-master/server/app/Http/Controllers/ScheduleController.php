<?php

namespace App\Http\Controllers;

use App\Models\Schedule;
use App\Models\User;
use App\Models\Lab;
use App\Models\TheClass;
use App\Models\Subject;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Http\Resources\MyCollection;
use App\Exceptions\ResponseException;

use RRule\RRule;
use Illuminate\Support\Arr;


class ScheduleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        if (request()->has('resources')) {
            return [
                [
                    'title' => 'User Id',
                    'fieldName' => 'user_id',
                    'instances' => User::select('id', 'full_name AS text')->get()
                ],
                [
                    'title' => 'Lab Id',
                    'instances' => Lab::select('id', 'id AS text')->get()
                ],
                [
                    'title' => 'Class Id',
                    'fieldName' => 'class_id',
                    'instances' => TheClass::select('id', 'id AS text')->get()
                ],
                [
                    'title' => 'Subject Id',
                    'fieldName' => 'subject_id',
                    'instances' => Subject::select(['id', 'name as text'])->get()
                ],
            ];
        }

        $params = request()->all();

        $schedules = Schedule::filter($params)
            ->sort($params)
            ->get();

        return [
            'pagination' => [],
            'rows' => $schedules
        ];
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        try {

            $params = $request->all();

            [
                'user_id' => $user_id
            ] = $params;

            $user =  User::find($user_id);

            if (!$user) {
                throw new ResponseException('Not found', 404, 'user_id');
            }

            $user->checkRequestData($request);


            if ($user->role == 'Teacher') {
                $params = Arr::except($params, 'pay');
            }

            if ($user->role == 'Employeer') {
                $params = Arr::except($params, ['class_id', 'subject_id']);
            }

            return Schedule::create($params);
        } catch (ResponseException $e) {
            return $e->getResponse();
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return Schedule::find($id)->with(['user', 'lab', 'class', 'subject'])->get();
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        return Schedule::find($id)->update($request->all());
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return Schedule::destroy($id);
    }
}
