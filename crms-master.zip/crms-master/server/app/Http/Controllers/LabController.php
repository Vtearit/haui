<?php

namespace App\Http\Controllers;

use App\Exceptions\ResponseException;
use Illuminate\Http\Request;
use App\Http\Resources\MyCollection;
use App\Models\Lab;
use Exception;

class LabController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $params = request()->all();

        if (request()->has('ids')) {
            return Lab::pluck('id')->toArray();
        }


        $per_page = intval(request()->input('per_page', 10));
        $results = Lab::filter($params)->sort($params)->paginate($per_page);

        return new MyCollection($results);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $params = $request->all();
        if (request()->filled('select')) {
            $cols = explode(',', $params['select']);
            return Lab::select($cols)->filter($params)->get();
        }
        if (Lab::find($params['id'])) {

            return response()->json([
                "id" => "Id is already existed",
            ], 400);
        }
        return Lab::create($params);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return Lab::find($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        try {
            $lab = Lab::find($id);

            if (!$lab) {
                throw new ResponseException("Not found", 404, 'id');
            }

            return $lab->update($request->all());
        } catch (\PDOException $e) {
            return response()->json(['id' => 'Id is already exists'], 409);
        } catch (ResponseException $e) {
            return $e->getResponse();
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return Lab::destroy($id);
    }
}
