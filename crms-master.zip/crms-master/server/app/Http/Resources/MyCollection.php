<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class MyCollection extends JsonResource
{
    private $pagination;

    public function __construct($resource)
    {
        $this->pagination = [
            'total' => $resource->total(),
            'per_page' => $resource->perPage(),
            'current_page' => $resource->currentPage(),
        ];

        $resource = $resource->getCollection();

        parent::__construct($resource);
    }
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $sort = (object) [
            'sort' => $request->input('sort', 'id'),
            'dir' => $request->input('dir', 'asc')
        ];

        return [
            'pagination' => $this->pagination,
            'sort' => $sort,
            'rows' => $this->resource,
        ];
    }
}
