<?php

namespace App\Exceptions;

use Exception;

class ResponseException extends Exception
{
    private $field = '';

    public function __construct($message, $code, $field)
    {
        $this->field = $field;
        parent::__construct($message, $code);
    }

    public function getResponse()
    {
        return response()->json([
            $this->field => parent::getMessage()
        ], parent::getCode());
    }
}
