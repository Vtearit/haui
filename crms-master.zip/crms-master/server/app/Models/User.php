<?php

namespace App\Models;

use Illuminate\Support\Facades\Hash;

use App\Shared\UuidGenerator;
use App\Models\BaseModel;
use App\Models\Schedule;
use DateTime;
use Illuminate\Support\Facades\DB;
use RRule\RRule;
use App\Exceptions\ResponseException;
use Tymon\JWTAuth\Contracts\JWTSubject;

class User extends BaseModel implements JWTSubject
{
    protected $primaryKey = 'id';
    public $incrementing = false;

    protected $fillable = [
        'id',
        'full_name',
        'email',
        'password',
        'role',
    ];

    protected $hidden  = [
        'password',
    ];

    protected $filterable = [
        'id',
        'full_name',
        'email',
        'role',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $sortable = [
        'id',
        'full_name',
        'email',
        'role',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    public function getJWTIdentifier()
    {
        return $this->getKey();
    }
    public function getJWTCustomClaims()
    {
        return [];
    }

    public function setPasswordAttribute($password)
    {
        $this->attributes['password'] = Hash::make($password);
    }

    public function filterRole($query, $value)
    {
        return $query->where('role', $value);
    }

    public function schedules()
    {
        return $this->hasMany(Schedule::class, 'user_id', 'id');
    }

    public function activeTsime($start_date, $end_date, $rRule)
    {
        return [
            'DB' => $this
                ->schedules()
                ->select('startDate', 'endDate', 'rRule')
                ->WhereTime('startDate', '>=', $start_date)
                ->WhereTime('endDate', '<=', $end_date)
                ->whereNotNull('rRule')
                ->get()
                ->map(function ($row) {
                    [
                        "startDate" => $startDate,
                        "endDate" => $endDate,
                        "rRule" => $rRule,
                    ] = $row;

                    $days = (new RRule($rRule, $startDate))->getOccurrences();

                    return collect($days)
                        ->map(function ($o) use ($startDate, $endDate) {

                            $day = $o->format('Y-m-d') . " ";

                            $start =  $day . (new DateTime($startDate))->format('H:i:s');
                            $end =  $day . (new DateTime($endDate))->format('H:i:s');
                            return [$start, $end];
                        });
                }),
            'response' => collect((new RRule($rRule, $start_date))->getOccurrences())->map(function ($o) {
                return $o->format("Y-m-d");
            })
        ];
    }

    public function payedSchedules()
    {
        $schedules = $this->schedules()->get();
        if ($this->role == 'Employeer') {

            $schedules = $schedules->map(function ($row) {
                [
                    "startDate" => $startDate,
                    "endDate" => $endDate,
                    'rRule' => $rRule,
                    'pay' => $moneyPerHour
                ] = $row;

                $hoursPerShift = $startDate->diffInHours($endDate);

                $countShift = 1;
                if ($rRule) {
                    $rule = new RRule($rRule, $startDate);
                    $countShift = collect($rule->getOccurrences())
                        ->count();
                }
                $row['shiftsCount'] = $countShift;
                $row['totalPay'] = $hoursPerShift * $countShift * $moneyPerHour;

                return $row;
            });
        }
        $this['schedules'] = $schedules;
        return $this;
    }

    public function checkRequestData($request)
    {

        if ($this->role == 'Teacher') {
            if (!$request->filled('class_id')) {
                throw new ResponseException(
                    'Class is required for teacher',
                    400,
                    'class_id'
                );
            }

            if (!$request->filled('subject_id')) {
                throw new ResponseException(
                    'Subject is required for teacher',
                    400,
                    'subject_id'
                );
            }
        }

        if ($this->role == 'Employeer') {
            if (!$request->filled('pay')) {
                throw new ResponseException(
                    'Employeer requires pay',
                    400,
                    'pay'
                );
            }
        }
    }
}
