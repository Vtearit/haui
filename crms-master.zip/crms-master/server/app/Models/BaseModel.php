<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

use App\Shared\Filterable;
use App\Shared\Sortable;

abstract class BaseModel extends Model
{
   use HasFactory;
   use Filterable;
   use Sortable;
   use SoftDeletes;

   protected $casts = [
      "status" => 'float',
      'created_at' => 'datetime:H:i A d/m/Y',
      'updated_at' => 'datetime:H:i A d/m/Y',
      'deleted_at' => 'datetime:H:i A d/m/Y',
   ];

   public function __get($key)
   {
      return $this->getAttribute($key);
   }
}
