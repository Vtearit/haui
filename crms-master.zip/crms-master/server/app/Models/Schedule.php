<?php

namespace App\Models;

use App\Shared\UuidGenerator;
use App\Models\BaseModel;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Schedule extends BaseModel
{
    use HasFactory;
    use UuidGenerator;

    protected $primaryKey = 'id';
    public $incrementing = false;

    protected $hidden = [];

    protected $fillable = [
        'user_id',
        'lab_id',
        'class_id',
        'subject_id',

        'startDate',
        'endDate',
        'allDay',
        'rRule',
        'note',
        'pay'
    ];

    protected $filterable = [
        'user_id',
        'lab_id',
        'class_id',
        'subject_id',

        'startDate',
        'endDate',
    ];

    protected $sortable = [
        'user_id',
        'lab_id',
        'class_id',
        'subject_id',
        'startDate',
        'endDate',
    ];


    protected $casts = [
        'allDay' => 'boolean',
        'startDate' => 'datetime:Y-m-d H:i:s',
        'endDate' => 'datetime:Y-m-d H:i:s',
    ];

    public function filterStartAt($query, $value)
    {
        return $query->whereDate('start_at', "LIKE", $value . "%");
    }
    public function filterEndAt($query, $value)
    {
        return $query->whereDate('end_at', "LIKE", $value . "%");
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

    public function lab()
    {
        return $this->belongsTo(Lab::class, 'lab_id', 'id');
    }

    public function subject()
    {
        return $this->belongsTo(Subject::class, 'subject_id', 'id');
    }

    public function class()
    {
        return $this->belongsTo(TheClass::class, 'class_id', 'id');
    }
}
