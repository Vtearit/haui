<?php

namespace App\Models;


class Lab extends BaseModel
{

    public $incrementing = false;
    protected $primaryKey = 'id';

    protected $fillable = [
        'id',
        'building',
        'room',
        'note'
    ];

    protected $filterable = [
        'id',
        'building',
        'room',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $sortable = [
        'id',
        'building',
        'room',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    public function computers()
    {
        return $this->hasMany(Computer::class, 'lab_id', 'id');
    }
}
