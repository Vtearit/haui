<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;


class Computer extends BaseModel
{
    use HasFactory;

    protected $primaryKey = 'id';

    protected $fillable = [
        'id',
        'status',
        'note',
        'lab_id',
    ];

    protected $filterable = [
        'id',
        'status',
        'lab_id',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $sortable = [
        'id',
        'status',
        'lab_id',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    public function lab()
    {
        return $this->belongsTo(Lab::class, 'lab_id', 'id');
    }
}
