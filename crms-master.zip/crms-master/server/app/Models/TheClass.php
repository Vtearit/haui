<?php

namespace App\Models;


class TheClass extends BaseModel
{

   protected $primaryKey = 'id';
   public $incrementing = false;

   protected $fillable = [
      'id',
      'name',
      'school_start',
      'school_end',
      'note'
   ];

   protected $filterable = [
      'id',
      'name',
      'school_start',
      'school_end',
      'created_at',
      'updated_at',
      'deleted_at'
   ];

   protected $sortable = [
      'id',
      'name',
      'school_start',
      'school_end',
      'created_at',
      'updated_at',
      'deleted_at'
   ];
}
