<?php

namespace App\Models;


class Subject extends BaseModel
{

    public $incrementing = false;
    protected $primaryKey = 'id';

    protected $fillable = [
        'id',
        'name',
        'note',
    ];

    protected $filterable = [
        'id',
        'name',
        'created_at',
        'updated_at',
        'deleted_at'
    ];

    protected $sortable = [
        'id',
        'name',
        'created_at',
        'updated_at',
        'deleted_at'
    ];
}
