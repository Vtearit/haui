<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSchedulesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('schedules', function (Blueprint $table) {
            $table->uuid('id')->primary();

            $table->string('user_id');
            $table->string('lab_id');
            $table->string('class_id')->nullable();
            $table->string('subject_id')->nullable();

            $table->dateTime('start_date');
            $table->dateTime('end_date')->nullable(); // depent on allDay flag

            $table->boolean('all_day')->nullable();
            $table->string('r_rule')->nullable();
            $table->string('ex_date')->nullable();
            $table->text('note')->nullable();

            $table->timestamps();
            $table->softDeletes();

            $table->foreign('user_id')
                ->references('id')->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');

            $table->foreign('lab_id')
                ->references('id')->on('labs')
                ->onUpdate('cascade')
                ->onDelete('cascade');


            $table->foreign('class_id')
                ->references('id')->on('the_classes')
                ->onUpdate('cascade')
                ->onDelete('cascade');


            $table->foreign('subject_id')
                ->references('id')->on('subjects')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('schedules');
    }
}
