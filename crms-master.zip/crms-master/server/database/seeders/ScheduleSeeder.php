<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\Schedule;

class ScheduleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $admin = DB::table('users')->where('role', '=', 'Admin')->first();
        $teacher = DB::table('users')->where('role', '=', 'Teacher')->first();
        $employeer = DB::table('users')->where('role', '=', 'employeer')->first();

        $subject = ['IT6005', 'IT6008', 'IT6020', 'IT6021', 'IT6022', 'IT6024', 'IT6028', 'IT6029', 'IT6030', 'IT6033', 'IT6034'];
        $classes = ['2017CNTT02', '2017CNTT03', '2017HTMT01', '2017HTMT02', '2017HTMT03', '2017KHMT01', '2017KHMT02', '2017KHMT03', '2017KTPM01', '2017KTPM02', '2017KTPM03'];
        $labs = ['A1-702', 'A1-703', 'A1-704', 'A1-801', 'A1-802', 'A1-803', 'A1-804', 'A1-901', 'A1-902', 'A1-903', 'A1-904'];



        foreach (array_merge($labs, $labs, $labs) as $lab) {
            // Schedule::factory()->            
        }
    }
}
