<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Computer;

class ComputerSeeder extends Seeder
{
    public function run()
    {
        $labs = ['A1-701', 'A1-702', 'A1-703', 'A1-704', 'A1-801', 'A1-802', 'A1-803', 'A1-804', 'A1-901', 'A1-902', 'A1-903', 'A1-904'];

        for ($i = 0; $i < 360; $i++) {
            Computer::factory()->create(['lab_id' => $labs[$i % 12]]);
        }
    }
}
