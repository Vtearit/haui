<?php

namespace Database\Seeders;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Seeder;
use App\Models\TheClass;

class TheClassSeeder extends Seeder
{

    private $classes = [
        '2017KTPM01' => 'Kỹ thuật phần mềm',
        '2017CNTT01' => 'Công nghệ thông tin',
        '2017HTMT01' => 'Hệ thống máy tính',
        '2017KHMT01' => 'Khoa học máy tính',

        '2017KTPM02' => 'Kỹ thuật phần mềm',
        '2017CNTT02' => 'Công nghệ thông tin',
        '2017HTMT02' => 'Hệ thống máy tính',
        '2017KHMT02' => 'Khoa học máy tính',

        '2017KTPM03' => 'Kỹ thuật phần mềm',
        '2017CNTT03' => 'Công nghệ thông tin',
        '2017HTMT03' => 'Hệ thống máy tính',
        '2017KHMT03' => 'Khoa học máy tính',
    ];
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('the_classes')->delete();
        foreach ($this->classes as $id => $name) {
            TheClass::factory()->create(['id' => $id, 'name' => $name]);
        }
    }
}
