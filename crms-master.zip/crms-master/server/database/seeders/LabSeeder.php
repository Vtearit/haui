<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Lab;

class LabSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */


    private $labs = [
        ['id' => 'A1-701', 'building' => 'A1', 'room' => 701],
        ['id' => 'A1-702', 'building' => 'A1', 'room' => 702],
        ['id' => 'A1-703', 'building' => 'A1', 'room' => 703],
        ['id' => 'A1-704', 'building' => 'A1', 'room' => 704],

        ['id' => 'A1-801', 'building' => 'A1', 'room' => 801],
        ['id' => 'A1-802', 'building' => 'A1', 'room' => 802],
        ['id' => 'A1-803', 'building' => 'A1', 'room' => 803],
        ['id' => 'A1-804', 'building' => 'A1', 'room' => 804],

        ['id' => 'A1-901', 'building' => 'A1', 'room' => 901],
        ['id' => 'A1-902', 'building' => 'A1', 'room' => 902],
        ['id' => 'A1-903', 'building' => 'A1', 'room' => 903],
        ['id' => 'A1-904', 'building' => 'A1', 'room' => 904],
    ];

    public function run()
    {
        foreach ($this->labs as $lab) {
            Lab::factory()->create($lab);
        }
    }
}
