<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\Subject;

class SubjectSeeder extends Seeder
{
    private $subjects = [
        'IT6008' => 'Đảm bảo chất lượng phần mềm',
        'IT6024' => 'Một số công nghệ phát triển phần mềm',
        'IT6033' => 'Quản lý dự án công nghệ thông tin',
        'IT6004' => 'Công nghệ đa phương tiện',
        'IT6005' => 'Công nghệ thực tại ảo',
        'IT6020' => 'Lập trình Java nâng cao',
        'IT6021' => 'Lập trình Web bằng ASP.NET',
        'IT6022' => 'Lập trình web bằng PHP',
        'IT6028' => 'Phát triển ứng dụng Game',
        'IT6029' => 'Phát triển ứng dụng trên thiết bị di động',
        'IT6030' => 'Phần mềm mã nguồn mở',
        'IT6034' => 'Tích hợp hệ thống phần mềm',
    ];
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('subjects')->delete();
        foreach ($this->subjects as $id => $name) {
            Subject::factory()->create(['id' => $id, 'name' => $name]);
        }
    }
}
