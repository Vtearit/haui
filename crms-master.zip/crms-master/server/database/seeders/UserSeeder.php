<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;

class UserSeeder extends Seeder
{
    private $users = [
        ['full_name' => 'Admin', 'email' => 'admin@email.com', 'password' => 'qweasd', 'role' => 'Admin'],
        ['full_name' => 'Teacher', 'email' => 'teacher@email.com', 'password' => 'qweasd', 'role' => 'Teacher'],
        ['full_name' => 'Employeer', 'email' => 'employeer@email.com', 'password' => 'qweasd', 'role' => 'Employeer'],
    ];
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        foreach ($this->users as $u) {
            User::factory()->create($u);
        }
    }
}
