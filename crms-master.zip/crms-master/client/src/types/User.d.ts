import { Timestamp, Collection, Schedule } from ".";
declare interface UserModel {
	id: string;
	full_name: string;
	email: string;
	role: string;
	schedules?: (Schedule & { shiftsCount: number; totalPay: number })[];
}

export declare interface User extends Timestamp, UserModel {}

export declare type Users = Collection<User>;
