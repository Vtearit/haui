import { Timestamp, Collection } from "./";
declare interface SubjectModel {
	id: string;
	name: boolean;
	note?: string;
}

export declare interface Subject extends Timestamp, SubjectModel {}

export declare type Subjects = Collection<Subject>;
