export interface Pagination {
	total: number;
	per_page: number;
	current_page: number;
}

export interface SortModel {
	sort: string;
	dir: string;
}

export interface Collection<T> {
	pagination: Pagination;
	sort: SortModel;
	rows: T[];
}
