import { Timestamp, Collection } from ".";
declare interface ClassModel {
	id: string;
	building: boolean;
	room: string | number;
	note: string;
}

export declare interface Class extends Timestamp, ClassModel {}

export declare type Classes = Collection<Class>;
