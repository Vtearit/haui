import { Timestamp, Collection } from "./";
declare interface ScheduleModel {
	id: string;
	user_id: string;
	lab_id: string;
	class_id?: string;
	subject_id?: string;
	startDate: Date;
	endDate: Date;
	allDay: boolean;
	rRule?: string;
	note?: string;
	pay?: number;
}

export declare interface Schedule extends ScheduleModel, Timestamp {}

export declare type Schedules = Collection<Schedule>;
