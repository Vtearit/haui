import { Timestamp, Collection } from "./";
declare interface LabModel {
	id: string;
	building: string;
	room: string | number;
	note: string;
}

export declare interface Lab extends Timestamp, LabModel {}

export declare type Labs = Collection<Lab>;
