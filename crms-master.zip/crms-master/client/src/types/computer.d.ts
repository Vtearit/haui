import { Timestamp, Collection } from "./";

export interface ComputerModel {
	id: number;
	status: number;
	note: string | null;
	lab_id: string | null;
}

export interface Computer extends Timestamp, ComputerModel {}

export declare type Computers = Collection<Computer>;
