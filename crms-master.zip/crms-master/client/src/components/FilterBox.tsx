import React from "react";

import {
	GridProps,
	Paper,
	TextField,
	Grid,
	Button,
	MenuItem,
} from "@material-ui/core";
import { Search as SearchIcon, Redo as ResetIcon } from "@material-ui/icons";
import { useFilter, useGapsStyle } from "@hooks";
import { useForm, Controller } from "react-hook-form";
import { Pagination } from "@types";
import { useRouter } from "next/router";
import _ from "lodash";

import { DatePicker } from "@material-ui/pickers";

type Field = {
	name?: string;
	md: number;
	type?: "date" | "number" | "datetime-local" | undefined;
	options?: string[];
};
export interface FilterBoxProps {
	fields: Field[];
	pagination: Pagination;
}

export const FilterBox: React.FunctionComponent<FilterBoxProps> = ({
	fields,
	pagination,
}) => {
	const filter = useFilter();
	const classes = useGapsStyle();
	const { query, push } = useRouter();

	const { register, handleSubmit, reset, control } = useForm({
		defaultValues: query,
	});

	return (
		<Paper variant="outlined" style={{ padding: 16 }}>
			<Grid
				container
				component="form"
				spacing={2}
				onSubmit={handleSubmit((data) => filter({ data, pagination }))}
			>
				{fields.map(({ md, options, name, type }, key) => {
					const label = _.startCase(name);

					if (!name) {
						return <GridItem md={md} key={key} />;
					}

					if (options) {
						return (
							<GridItem md={md} key={key}>
								<Controller
									name={name}
									// @ts-ignore
									control={control}
									render={({ value, onChange }) => (
										<TextField
											select
											label={label}
											value={value}
											onChange={onChange}
										>
											{options.map((val) => (
												<MenuItem value={val}>{val}</MenuItem>
											))}
										</TextField>
									)}
								/>
							</GridItem>
						);
					}

					if (type === "date") {
						return (
							<GridItem md={md} key={key}>
								<Controller
									name={name}
									// @ts-ignore
									control={control}
									render={({ value = null, onChange }) => (
										<DatePicker
											label={label}
											value={value}
											format="DD/MM/yyyy"
											onChange={(d) =>
												onChange(d?.format("yyyy-MM-DD").toString())
											}
										/>
									)}
								/>
							</GridItem>
						);
					}

					if (type === "datetime-local") {
						return (
							<GridItem md={md} key={key}>
								datetime-local
							</GridItem>
						);
					}

					return (
						<GridItem md={md} key={key}>
							<TextField
								label={label}
								inputRef={register}
								name={name}
								fullWidth
							/>
						</GridItem>
					);
				})}
				<Grid item md={12} className={classes.gaps}>
					<Button
						variant="contained"
						color="primary"
						type="submit"
						startIcon={<SearchIcon />}
					>
						Search
					</Button>
					<Button
						color="primary"
						startIcon={<ResetIcon />}
						variant="text"
						onClick={() => {
							reset();
							push({ query: {} });
						}}
					>
						Reset
					</Button>
				</Grid>
			</Grid>
		</Paper>
	);
};

interface GridItemProps extends Omit<GridProps, "md"> {
	md: number | boolean;
}

const GridItem: React.FunctionComponent<GridItemProps> = ({
	item,
	md,
	...props
	// @ts-ignore
}) => <Grid {...props} item md={md} />;
