import { useGapsStyle } from "@hooks";
import {
	Send as SendIcon,
	Redo as ResetIcon,
	Close as CancelIcon,
} from "@material-ui/icons";

import { Link } from "./";
import { Button, CircularProgress } from "@material-ui/core";

export interface SubmitButtonProps {
	loading: boolean;
	resource: string;
	resetHandler: () => void | undefined;
}

export const SubmitButton: React.FunctionComponent<SubmitButtonProps> = ({
	resource,
	loading,
	resetHandler,
}) => {
	const classes = useGapsStyle();

	return (
		<div className={classes.gaps}>
			<Button
				color="primary"
				type="submit"
				variant="contained"
				disabled={loading}
				startIcon={
					loading ? (
						<CircularProgress color="secondary" size={16} />
					) : (
						<SendIcon />
					)
				}
			>
				Send
			</Button>
			<Button
				color="inherit"
				startIcon={<ResetIcon />}
				variant="text"
				onClick={() => resetHandler()}
			>
				Reset
			</Button>

			{/* @ts-ignore */}
			<Button
				color="inherit"
				startIcon={<CancelIcon />}
				variant="text"
				component={Link}
				href={`/u/${resource}`}
			>
				Cancel
			</Button>
		</div>
	);
};
