import React from "react";
import { Button, CircularProgress } from "@material-ui/core";

import { Add as CreateIcon, Delete as DeleteIcon } from "@material-ui/icons";

import { useGapsStyle } from "@hooks";
import { Link } from "@components";

export interface ResourceActionsProps {
	resource: string;
	disabledDelete: boolean;
	loading: boolean;

	onDelete: (e: any) => any;
}

export const ResourceActions: React.FunctionComponent<ResourceActionsProps> = ({
	resource,
	disabledDelete,
	onDelete,
	loading,
}) => {
	const classes = useGapsStyle();

	return (
		<div className={classes.gaps}>
			{/* @ts-ignore */}
			<Button
				href={`/u/${resource}/create`}
				component={Link}
				naked
				color="primary"
				variant="contained"
				startIcon={<CreateIcon />}
			>
				Create
			</Button>
			<Button
				startIcon={loading ? <CircularProgress size={16} /> : <DeleteIcon />}
				disabled={disabledDelete || loading}
				color="secondary"
				variant="contained"
				onClick={onDelete}
			>
				Delete
			</Button>
		</div>
	);
};

export default ResourceActions;
