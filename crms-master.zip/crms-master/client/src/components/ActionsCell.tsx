import React from "react";
import { IconButton } from "@material-ui/core";
import { RowId } from "@material-ui/data-grid";

import {
	Delete as DeleteIcon,
	Search as SearchIcon,
	Edit as EditIcon,
} from "@material-ui/icons";

import { Link } from "@components";
import { DeleteHandler } from "@hooks";
export interface ActionCellProps {
	resource: string;
	rowId: RowId;
	deleteHandler?: DeleteHandler;
}

export const ActionsCell: React.FunctionComponent<ActionCellProps> = ({
	resource,
	rowId,
	deleteHandler,
}) => {
	return (
		<React.Fragment>
			<IconButton
				aria-label="Details"
				component={Link}
				href={`/u/${resource}/${rowId}/show`}
			>
				<SearchIcon />
			</IconButton>
			<IconButton component={Link} href={`/u/${resource}/${rowId}/edit`}>
				<EditIcon />
			</IconButton>
			<IconButton onClick={() => deleteHandler && deleteHandler([rowId])}>
				<DeleteIcon />
			</IconButton>
		</React.Fragment>
	);
};
