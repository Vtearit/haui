import { Link } from "@components";
import {
	Typography,
	Breadcrumbs as MuiBreadScrumbs,
	BreadcrumbsProps,
} from "@material-ui/core";
import { useRouter } from "next/router";
import { Route } from "@layout";

interface BreadScrumbsProps extends BreadcrumbsProps {
	nameMapping: Route;
}

export const BreadScrumbs: React.FunctionComponent<BreadScrumbsProps> = ({
	nameMapping,
	...rest
}) => {
	const router = useRouter();
	const pathnames = router.pathname.split("/").filter((x) => x);

	return (
		<MuiBreadScrumbs aria-label="breadcrumb" {...rest}>
			{pathnames.map((_, index) => {
				const href = `/${pathnames.slice(0, index + 1).join("/")}`;

				const title = nameMapping[href]?.title;
				if (!title) {
					return null;
				}

				const last = index === pathnames.length - 1;
				if (last) {
					return <Typography key={index}>{title}</Typography>;
				}

				return (
					<Link href={href} key={index} underline="hover">
						{title}
					</Link>
				);
			})}
		</MuiBreadScrumbs>
	);
};
