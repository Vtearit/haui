import React, { FunctionComponent, useCallback } from "react";

import {
	DataGridProps,
	DataGrid,
	PageChangeParams,
	SortModelParams,
	SortDirection,
} from "@material-ui/data-grid";

import { makeStyles } from "@material-ui/core";

import { Pagination, SortModel } from "@types";
import { ActionsCell, Paginator } from "@components";
import { useRouter } from "next/router";
import { DeleteHandler } from "@hooks";

export interface MyDatagridProps extends DataGridProps {
	paginate: Pagination;
	sort: SortModel;
	onPagination?: (params: PageChangeParams) => void | undefined;
	onSort?: (models: SortModelParams) => void | undefined;
	resource?: string;
	deleteHandler?: DeleteHandler;
}

const useStyles = makeStyles(() => ({
	root: {
		height: 600,
	},
	actions: {
		marginLeft: -16,
		display: "flex",
	},
}));

export const MyDatagrid: FunctionComponent<MyDatagridProps> = ({
	paginate: { per_page, total },
	sort,
	onPagination,
	onSort,
	columns,
	resource,
	onSelectionChange,
	deleteHandler,
	...rest
}) => {
	const classes = useStyles();
	const { query, push } = useRouter();

	const defaultOnSort = useCallback(
		({ sortModel }: SortModelParams) => {
			const { field, sort } = sortModel[0];

			if (query.sort != field || query.dir != sort?.toString()) {
				push({
					query: {
						...query,
						sort: field,
						dir: sort,
					},
				});
			}
		},
		[sort.sort, sort.dir]
	);

	columns.push(
		{
			field: "created_at",
			headerName: "Created At",
			type: "date",
			width: 160,
		},
		{
			field: "updated_at",
			headerName: "Updated At",
			type: "date",
			width: 200,
		}
	);

	if (resource) {
		columns.push({
			field: "actions",
			sortable: false,
			headerName: "Actions",
			width: 150,
			cellClassName: classes.actions,
			renderCell: ({ row: { id } }) => (
				<ActionsCell
					resource={resource}
					rowId={id}
					deleteHandler={deleteHandler}
				/>
			),
		});
	}

	return (
		<div className={classes.root}>
			<DataGrid
				{...rest}
				columns={columns}
				rowCount={total}
				pageSize={per_page}
				/**
				 * sort
				 */
				sortModel={
					query.sort && query.dir
						? [
								{
									field: sort.sort,
									sort: sort.dir as SortDirection,
								},
						  ]
						: undefined
				}
				onSortModelChange={onSort || defaultOnSort}
				sortingOrder={["asc", "desc"]}
				/**
				 * stuffs
				 */
				components={{
					pagination: Paginator,
				}}
				checkboxSelection={Boolean(onSelectionChange)}
				onSelectionChange={onSelectionChange}
				disableSelectionOnClick
				disableMultipleColumnsSorting
				pagination
				paginationMode="server"
				sortingMode="server"
			/>
		</div>
	);
};

export default MyDatagrid;
