import React from "react";
import { useRouter } from "next/router";

import {
	FormControl,
	InputLabel,
	makeStyles,
	MenuItem,
	Select,
	Theme,
	Typography,
} from "@material-ui/core";
import { Pagination } from "@material-ui/lab";
import { ComponentProps } from "@material-ui/data-grid";

const useStyles = makeStyles((theme: Theme) => ({
	root: {
		display: "flex",
		alignItems: "center",
	},
	select: {
		minWidth: 120,
		margin: theme.spacing(0, 2),
	},
}));

export interface PaginatorProps extends ComponentProps {}

export const Paginator: React.FunctionComponent<PaginatorProps> = (props) => {
	const { pagination } = props;
	const { push, query } = useRouter();

	const classes = useStyles();

	return (
		<div className={classes.root}>
			<Typography variant="body2">{`Total: ${pagination.rowCount}`}</Typography>
			<FormControl variant="outlined" className={classes.select}>
				<InputLabel id="per-page-label">Rows per page</InputLabel>
				<Select
					labelId="per-page-label"
					style={{ height: 32 }}
					labelWidth={100}
					value={Number(query.per_page) || 10}
					onChange={(e) =>
						push({
							query: { ...query, page: 1, per_page: Number(e.target.value) },
						})
					}
				>
					{[10, 25, 50].map((value, key) => (
						<MenuItem value={value} key={key}>
							{value}
						</MenuItem>
					))}
				</Select>
			</FormControl>
			<Pagination
				color="primary"
				page={Number(query.page) || 1}
				count={pagination.pageCount}
				onChange={(_, page) => push({ query: { ...query, page } })}
			/>
		</div>
	);
};
