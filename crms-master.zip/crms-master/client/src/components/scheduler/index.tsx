import React, { FunctionComponent, useContext } from "react";
import {
	Grid,
	Drawer,
	Box,
	FormControlLabel,
	Checkbox,
	TextField,
	MenuItem,
	Typography,
	FormControl,
	FormLabel,
	RadioGroup,
	Radio,
	FormHelperText,
} from "@material-ui/core";

import { AppointmentForm } from "@devexpress/dx-react-scheduler-material-ui";

import { Controller, useForm } from "react-hook-form";

import { useCreateOrUpdateSchedule } from "@hooks";
import { useRouter } from "next/router";
import {
	ActionToolbar,
	MyDateEditor,
	ResourceSelector,
	WeekdaySelector,
} from "./components";

import _ from "lodash";
import { Frequency, RRule } from "rrule";

export const onHideContext = React.createContext<{
	visible: boolean;
	onHide: () => void;
}>({ visible: false, onHide: () => {} });

export const MyOverlay: FunctionComponent<AppointmentForm.OverlayProps> = ({
	children,
	onHide,
	target,
	visible,
}) => {
	return (
		<Drawer ref={target} anchor="right" open={visible} onClose={onHide}>
			<onHideContext.Provider value={{ visible, onHide }}>
				{children}
			</onHideContext.Provider>
		</Drawer>
	);
};
export const MyLayout: FunctionComponent<AppointmentForm.LayoutProps> = ({
	basicLayoutComponent,
}) => {
	return React.createElement(basicLayoutComponent);
};

export const MyBasic: FunctionComponent<AppointmentForm.BasicLayoutProps> = ({
	appointmentData: {
		id: appointmentId,
		user_id,
		lab_id,
		class_id,
		subject_id,
		allDay,
		rRule: rRuleString,
		startDate,
		endDate,
		note,
		pay,
	},
	resources,
}) => {
	const { register, control, handleSubmit, watch, errors, setError } = useForm({
		defaultValues: {
			id: appointmentId,
			user_id,
			lab_id,
			class_id,
			subject_id,
			allDay,
			startDate,
			endDate,
			rRule: Object.assign(
				RRule.fromString(rRuleString || "RRULE:FREQ=DAILY;COUNT=1").options
			),
			isRecurrence: !_.isEmpty(rRuleString),
			note,
			pay,
		},
	});

	const allDayRef = React.useRef<boolean>();
	allDayRef.current = watch("allDay");

	const isRecurrenceRef = React.useRef<boolean>();
	isRecurrenceRef.current = watch("isRecurrence");

	const freqRef = React.useRef<Frequency>();
	freqRef.current = watch("rRule.freq");

	const { visible, onHide } = useContext(onHideContext);

	const router = useRouter();
	const { loading, createOrUpdateHandler } = useCreateOrUpdateSchedule({
		message: (data) =>
			`Schedule is ${
				typeof data === "number" ? "updated" : "saved"
			} successfuly`,
		redirect: router.asPath,
	});

	const submitHandler = handleSubmit(async ({ id, rRule, ...data }) => {
		const onlyCountOrUntil = _.omit(
			rRule,
			endRepeat === "count" ? "until" : "count"
		);

		try {
			await createOrUpdateHandler({
				// @ts-ignore because uuid is always string
				id: appointmentId,
				rRule: onlyCountOrUntil,
				...data,
			});
			if (visible) {
				onHide();
			}
		} catch (err) {
			for (const key in err) {
				setError(key, {
					type: "manual",
					message: err[key],
				});
			}
		}
	});

	const [endRepeat, setEndRepeat] = React.useState(
		rRuleString?.includes("UNTIL") ? "until" : "count"
	);

	return (
		<Box
			px={2}
			component="form"
			onSubmit={submitHandler}
			width={isRecurrenceRef.current ? "60vw" : "30vw"}
		>
			<ActionToolbar loading={loading} />
			<Grid container spacing={3} alignItems="flex-start">
				<Grid
					container
					item
					md={isRecurrenceRef.current ? 6 : 12}
					xs={12}
					spacing={2}
				>
					<Grid item md={6} xs={12}>
						<ResourceSelector
							name="user_id"
							control={control}
							rules={{
								required: {
									value: true,
									message: `${resources[0].title} is required`,
								},
							}}
							// @ts-ignore
							helperText={errors.user_id?.message || ""}
							resources={resources[0]}
						/>
					</Grid>

					<Grid item md={6} xs={12}>
						<TextField
							inputProps={{ type: "number", min: 0 }}
							label="Pay/h"
							name="pay"
							inputRef={register}
							error={Boolean(errors.pay)}
							helperText={errors.pay?.message || ""}
						/>
					</Grid>

					<Grid item md={12} xs={12}>
						<ResourceSelector
							name="lab_id"
							control={control}
							rules={{
								required: {
									value: true,
									message: `${resources[1].title} is required`,
								},
							}}
							// @ts-ignore
							helperText={errors.lab_id?.message || ""}
							resources={resources[1]}
						/>
					</Grid>

					{[
						{ md: 7, name: "class_id" },
						{ md: 5, name: "subject_id" },
					].map(({ md, name }, i) => (
						// @ts-ignore
						<Grid item md={md} xs={12}>
							<ResourceSelector
								name={name}
								control={control}
								resources={resources[i + 2]}
								// @ts-ignore
								helperText={errors[name]?.message || ""}
								key={i}
							/>
						</Grid>
					))}

					<Grid item md={12}>
						<Controller
							control={control}
							name="allDay"
							render={({ value, onChange }) => (
								<FormControlLabel
									label="All day"
									control={
										<Checkbox
											checked={value}
											onChange={(_, checked) => onChange(checked)}
											color="primary"
										/>
									}
								/>
							)}
						/>
						<Controller
							control={control}
							name="isRecurrence"
							render={({ value, onChange }) => (
								<FormControlLabel
									label="Repeat"
									control={
										<Checkbox
											checked={value}
											onChange={(_, checked) => onChange(checked)}
											color="primary"
										/>
									}
								/>
							)}
						/>
					</Grid>

					{[
						{ name: "startDate", label: "Start" },
						{ name: "endDate", label: "End" },
					].map(({ name, label }) => (
						<Grid item md={6} xs={12}>
							<MyDateEditor
								name={name}
								control={control}
								label={label}
								allDay={allDayRef.current}
							/>
						</Grid>
					))}
					<Grid item md={12}>
						<TextField
							multiline
							rows={3}
							name="note"
							inputRef={register}
							label="Note"
						/>
					</Grid>
				</Grid>

				{isRecurrenceRef.current && (
					<Grid
						container
						item
						md={isRecurrenceRef.current ? 6 : false}
						xs={isRecurrenceRef.current ? 12 : false}
						spacing={2}
					>
						<Grid item md={12}>
							<pre></pre>
						</Grid>
						<Grid item md={12}>
							<Controller
								name="rRule.freq"
								control={control}
								as={
									<TextField select label="Repeat">
										{[
											{ label: "Daily", value: RRule.DAILY },
											{ label: "Weekly", value: RRule.WEEKLY },
										].map(({ label, value }) => (
											<MenuItem value={value}>{label}</MenuItem>
										))}
									</TextField>
								}
							/>
						</Grid>
						<Grid item md={12}>
							<Typography gutterBottom>
								{"Repeat every "}
								<TextField
									variant="standard"
									name="rRule.interval"
									fullWidth={false}
									type="number"
									inputProps={{ min: 1 }}
									style={{ width: 50 }}
									inputRef={register}
								/>
								{` ${freqRef.current === RRule.DAILY ? "day" : "week"}(s)`}
							</Typography>
							{freqRef.current === RRule.WEEKLY && (
								<WeekdaySelector
									name="rRule.byweekday"
									allDay={allDayRef.current}
									control={control}
								/>
							)}
						</Grid>
						<Grid item md={12}>
							<FormControl
								component="fieldset"
								error={Boolean(errors.rRule?.count || errors.rRule?.until)}
							>
								<FormLabel component="legend">End Repeat</FormLabel>
								<RadioGroup
									value={endRepeat}
									onChange={(_, field) => setEndRepeat(field)}
								>
									<FormControlLabel
										style={{ marginBottom: 16, marginTop: 16 }}
										value="count"
										control={<Radio />}
										label={
											<TextField
												disabled={endRepeat !== "count"}
												inputProps={{ type: "number", min: 1 }}
												fullWidth={false}
												label="occurrence(s)"
												name="rRule.count"
												inputRef={register({
													required: {
														value: endRepeat === "count",
														message: "Number is required",
													},
												})}
											/>
										}
									/>

									<FormControlLabel
										style={{ marginBottom: 16 }}
										value="until"
										control={<Radio />}
										label={
											<MyDateEditor
												name="rRule.until"
												allDay={allDayRef.current}
												disabled={endRepeat !== "until"}
												label="Until"
												control={control}
											/>
										}
									/>
								</RadioGroup>
								<FormHelperText>
									{errors.rRule?.count?.message ||
										errors.rRule?.until?.message ||
										""}
								</FormHelperText>
							</FormControl>
						</Grid>
					</Grid>
				)}
			</Grid>
		</Box>
	);
};

export * from "./components";
