import React, { FunctionComponent } from "react";
import { DatePicker, DateTimePicker } from "@material-ui/pickers";

import {
	Button,
	makeStyles,
	LinearProgress,
	CircularProgress,
	Toolbar as MuiToolbar,
	IconButton,
	TextField,
	FormGroup,
	FormControlLabel,
	Checkbox,
} from "@material-ui/core";

import { Autocomplete } from "@material-ui/lab";

import { Close as CancelIcon, Save as SaveIcon } from "@material-ui/icons";

import { Resource } from "@devexpress/dx-react-scheduler";
import { Toolbar } from "@devexpress/dx-react-scheduler-material-ui";
import { useController, UseControllerOptions } from "react-hook-form";

import _ from "lodash";
import { onHideContext } from "./";

interface ResourceSelectorProps extends UseControllerOptions {
	resources: Resource;
	helperText?: React.ReactNode;
}
export const ResourceSelector: FunctionComponent<ResourceSelectorProps> = ({
	resources: { instances, allowMultiple, title },
	helperText,
	...props
}) => {
	const {
		field: { value, onChange, ref },
		meta: { invalid },
	} = useController(props);

	return (
		<Autocomplete
			multiple={allowMultiple}
			value={value}
			onChange={(_, value) => onChange(value)}
			options={instances.map(({ id }) => id)}
			renderInput={({ InputLabelProps, ...params }) => (
				<TextField
					{...params}
					label={title}
					InputLabelProps={{ ...InputLabelProps, shrink: true }}
					error={invalid}
					helperText={helperText}
					inputRef={ref}
				/>
			)}
		/>
	);
};

interface MyDateEditorProps extends UseControllerOptions {
	label: string;
	disabled?: boolean;
	allDay?: boolean;
}
export const MyDateEditor: FunctionComponent<MyDateEditorProps> = ({
	label,
	disabled,
	allDay,
	...props
}) => {
	const {
		field: { value, onChange },
	} = useController(props);

	if (allDay) {
		return (
			<DatePicker
				value={value}
				onChange={(d) => onChange(d?.toDate())}
				format="DD/MM/yyyy"
				inputVariant="outlined"
				label={label}
				fullWidth={false}
				disabled={disabled}
			/>
		);
	}

	return (
		<DateTimePicker
			value={value}
			onChange={(d) => onChange(d?.toDate())}
			format="DD/MM/yyyy hh:mm A"
			inputVariant="outlined"
			label={label}
			fullWidth={false}
			hideTabs
			disabled={disabled}
		/>
	);
};

const useStyles = makeStyles({
	root: {
		position: "relative",
	},
	progress: {
		position: "absolute",
		width: "100%",
		bottom: 0,
		left: 0,
	},
});

export const ToolbarWithLoading: React.FunctionComponent<Toolbar.RootProps> = ({
	children,
	...props
}) => {
	const classes = useStyles();

	return (
		<div className={classes.root}>
			<Toolbar.Root {...props}>{children}</Toolbar.Root>
			<LinearProgress className={classes.progress} />
		</div>
	);
};
export const ActionToolbar: React.FunctionComponent<{ loading: boolean }> = ({
	loading,
}) => {
	const { onHide } = React.useContext(onHideContext);

	return (
		<MuiToolbar disableGutters>
			<IconButton
				onClick={onHide}
				disabled={loading}
				size="small"
				color="default"
			>
				<CancelIcon />
			</IconButton>
			<div style={{ flexGrow: 1 }} />
			<Button
				type="submit"
				variant="contained"
				color="primary"
				disabled={loading}
				startIcon={
					loading ? (
						<CircularProgress color="secondary" size={16} />
					) : (
						<SaveIcon />
					)
				}
			>
				Save
			</Button>
		</MuiToolbar>
	);
};

const weekday = [
	"Monday",
	"Tuesday",
	"Wednesday",
	"Thursday",
	"Friday",
	"Saturday",
	"Sunday",
];
export const WeekdaySelector: React.FunctionComponent<
	UseControllerOptions & { allDay?: boolean }
> = ({ allDay, ...props }) => {
	const {
		field: { value, onChange },
	} = useController(props);

	return (
		<FormGroup>
			{weekday.map((label, i) => (
				<FormControlLabel
					control={
						<Checkbox
							name={i.toString()}
							checked={_.includes(value, i)}
							onChange={(event) =>
								onChange(_.xor(value, [Number(event.target.name)]))
							}
						/>
					}
					label={label}
				/>
			))}
		</FormGroup>
	);
};
