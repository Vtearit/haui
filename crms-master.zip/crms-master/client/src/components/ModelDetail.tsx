import * as React from "react";
import { Button, Typography } from "@material-ui/core";
import { Delete as DeleteIcon, Edit as EditIcon } from "@material-ui/icons";
import { Link } from "@components";
import { useGapsStyle, useDelete } from "@hooks";
import _ from "lodash";
export interface ModelDetailProps {
	resource: string;
	data: object;
	id: string;
}

export const ModelDetail: React.FunctionComponent<ModelDetailProps> = ({
	data,
	resource,
	id,
	children,
}) => {
	const classes = useGapsStyle();
	const { loading, deleteHandler } = useDelete(resource, {
		redirect: `/u/${resource}`,
		message: () => `Removed computer's id ${id}`,
	});

	return (
		<React.Fragment>
			<div className={classes.gaps}>
				{/*  @ts-ignore */}
				<Button
					color="primary"
					startIcon={<EditIcon />}
					component={Link}
					variant="contained"
					naked
					href={`/u/${resource}/${id}/edit`}
				>
					Edit
				</Button>
				<Button
					color="secondary"
					variant="contained"
					startIcon={<DeleteIcon />}
					disabled={loading}
					onClick={() => deleteHandler([id])}
				>
					Delete
				</Button>
			</div>
			<div>
				{_.keys(data).map((key, i) => (
					<React.Fragment key={i}>
						<Typography variant="subtitle2">{_.startCase(key)}</Typography>
						{/* @ts-ignore */}
						<Typography gutterBottom>{data[key] || "None"}</Typography>
					</React.Fragment>
				))}
				{children}
			</div>
		</React.Fragment>
	);
};
