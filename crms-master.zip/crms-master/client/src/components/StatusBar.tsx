import React, { DetailedHTMLProps, HTMLAttributes } from "react";

import { makeStyles, Theme } from "@material-ui/core/styles";
import clsx from "clsx";

export interface StatusBarProps
	extends DetailedHTMLProps<HTMLAttributes<HTMLDivElement>, HTMLDivElement> {
	value: number | any;
}

const useStyles = makeStyles((theme: Theme) => ({
	status: {
		width: "100%",
		height: 26,
		border: `1px solid ${theme.palette.divider}`,
		borderRadius: 2,
		position: "relative",
	},
	statusValue: {
		width: "100%",
		display: "flex",
		position: "absolute",
		lineHeight: "24px",
		justifyContent: "center",
	},
	statusBar: {
		height: "100%",

		"&.low": {
			backgroundColor: theme.palette.error.light,
		},
		"&.medium": {
			backgroundColor: theme.palette.warning.light,
		},
		"&.high": {
			backgroundColor: theme.palette.success.light,
		},
	},
}));

export const StatusBar: React.FunctionComponent<StatusBarProps> = ({
	value,
	className,
	...rest
}) => {
	const classes = useStyles();

	return (
		<div className={clsx(classes.status, className)} {...rest}>
			<div className={classes.statusValue}>{value + "%"}</div>
			<div
				style={{ maxWidth: `${value}%` }}
				className={clsx(classes.statusBar, {
					low: value <= 33.34,
					medium: value > 33.34 && value <= 66.67,
					high: value > 66.67 && value <= 100,
				})}
			/>
		</div>
	);
};
