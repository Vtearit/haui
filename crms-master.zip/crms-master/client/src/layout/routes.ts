import {
	Dashboard as DashboardIcon,
	Person as UsersIcon,
	Subject as SubjectsIcon,
	Group as ClassesIcon,
	Layers as LabsIcon,
	Computer as ComputersIcon,
	Event as ScheduleIcon,
	SvgIconComponent,
} from "@material-ui/icons";
import * as _ from "lodash";

export enum Role {
	Admin = "admin",
	Employer = "employeer",
	Teacher = "techer",
	Public = "public",
}

type RouteProps = {
	title?: string;
	icon?: SvgIconComponent;
	role?: Role[];
};

export type Route = {
	[key: string]: RouteProps;
};

/**
 * @ : [id]
 */
const routes: Route = {
	/**
	 * Dashboard
	 */
	"/u": { title: "Dashboard", icon: DashboardIcon },
	/**
	 * Schedule
	 */
	"/u/schedules": {
		title: "Schedules",
		icon: ScheduleIcon,
		role: [Role.Public],
	},
	"/u/schedules/create": { title: "Create", role: [Role.Public] },
	"/u/schedules/[id]/edit": { title: "Edit", role: [Role.Public] },
	"/u/schedules/[id]/show": { title: "Detail", role: [Role.Public] },
	/**
	 * user
	 */
	"/u/users": {
		title: "Users",
		icon: UsersIcon,
		role: [Role.Admin],
	},
	"/u/users/create": { title: "Invite User", role: [Role.Admin] },
	"/u/users/[id]/edit": { title: "Edit User", role: [Role.Admin] },
	"/u/users/[id]/show": { title: "Detail User", role: [Role.Admin] },
	/**
	 * Lab
	 */
	"/u/labs": {
		title: "Labs",
		icon: LabsIcon,
		role: [Role.Public],
	},
	"/u/labs/create": {
		title: "Create",
		role: [Role.Public],
	},
	"/u/labs/[id]/show": {
		title: "Detail",
		role: [Role.Public],
	},
	"/u/labs/[id]/edit": {
		title: "Edit",
		role: [Role.Public],
	},
	/**
	 * classes
	 */
	"/u/classes": {
		title: "Classes",
		icon: ClassesIcon,
		role: [Role.Admin, Role.Teacher],
	},
	"/u/classes/create": {
		title: "Create",
		role: [Role.Admin, Role.Teacher],
	},
	"/u/classes/[id]/edit": {
		title: "Edit",
		role: [Role.Admin, Role.Teacher],
	},
	"/u/classes/[id]/show": {
		title: "Show",
		role: [Role.Admin, Role.Teacher],
	},
	/**
	 * Subject
	 */
	"/u/subjects": {
		title: "Subjects",
		icon: SubjectsIcon,
		role: [Role.Admin, Role.Teacher],
	},
	"/u/subjects/create": {
		title: "Create",
		role: [Role.Public],
	},
	"/u/subjects/[id]/show": {
		title: "Detail",
		role: [Role.Public],
	},
	"/u/subjects/[id]/edit": {
		title: "Edit",
		role: [Role.Public],
	},
	/**
	 * Computer
	 */
	"/u/computers": {
		title: "Computers",
		icon: ComputersIcon,
		role: [Role.Public],
	},
	"/u/computers/create": {
		title: "Create",
		role: [Role.Public],
	},
	"/u/computers/[id]/show": {
		title: "Detail",
		role: [Role.Public],
	},
	"/u/computers/[id]/edit": {
		title: "Edit",
		role: [Role.Public],
	},

	/**
	 * profile
	 */
	"/u/profile": { title: "Profile" },
};

export default routes;
