import * as React from "react";
import styled from "styled-components";
import Layout, {
	Root,
	getHeader,
	getDrawerSidebar,
	getSidebarTrigger,
	getSidebarContent,
	getContent,
} from "@mui-treasury/layout";

import {
	makeStyles,
	Theme,
	Toolbar,
	Typography,
	Button,
	Avatar,
	Paper,
	Tabs,
	Tab,
} from "@material-ui/core";
import { BreadScrumbs, Link } from "@components";
import { useRouter } from "next/router";
import routes from "./routes";
import * as _ from "lodash";

const Header = getHeader(styled);
const DrawerSidebar = getDrawerSidebar(styled);
const SidebarTrigger = getSidebarTrigger(styled);
const SidebarContent = getSidebarContent(styled);
const Content = getContent(styled);

const schema = Layout();

const sidebarId = "fuckingId";

schema.configureHeader((builder) =>
	builder.registerConfig("xs", {
		position: "sticky",
		initialHeight: 64,
		clipped: true,
	})
);
schema.configureEdgeSidebar((builder) => {
	builder
		.create(sidebarId, { anchor: "left" })
		.registerTemporaryConfig("xs", {
			width: 200,
		})
		.registerPermanentConfig("md", { width: 200, collapsible: false });
});

export interface LayoutProps {
	dashboard: boolean;
}

const nameMap = Object.keys(routes).filter((k) => Boolean(routes[k].icon));

const useStyle = makeStyles((theme: Theme) => ({
	header: {
		display: "flex",
	},
	growMe: {
		flex: "1 1 auto",
	},
	avatar: {
		width: theme.spacing(4),
		height: theme.spacing(4),
	},

	p: {
		padding: theme.spacing(3),
	},
	mb: {
		marginBottom: theme.spacing(2),
	},
}));

const _Layout: React.FunctionComponent<LayoutProps> = ({
	children,
	dashboard,
}) => {
	const classes = useStyle();
	const { pathname } = useRouter();

	return dashboard ? (
		<Root scheme={schema} themeProviderOmitted>
			<Header elevation={3} color="primary">
				<Toolbar>
					<SidebarTrigger sidebarId={sidebarId} color="inherit" />
					<Typography variant="h6" component="h1">
						{"Application"}
					</Typography>
					<div className={classes.growMe} />
					<Button
						startIcon={<Avatar className={classes.avatar}>U</Avatar>}
						color="inherit"
						variant="text"
					>
						Username
					</Button>
				</Toolbar>
			</Header>

			<DrawerSidebar sidebarId={sidebarId}>
				<SidebarContent>
					<Tabs
						orientation="vertical"
						value={_.split(pathname, "/", 3).join("/")}
					>
						{nameMap.map((href, index) => {
							const obj = routes[href];

							return (
								<Tab
									// @ts-ignore
									icon={<obj.icon />}
									href={href}
									component={Link}
									value={href}
									key={index}
									label={obj.title}
									underline="none"
								/>
							);
						})}
					</Tabs>
				</SidebarContent>
			</DrawerSidebar>

			<Content className={classes.p}>
				<BreadScrumbs nameMapping={routes} className={classes.mb} />
				<Paper className={classes.p} variant="outlined">
					<Typography variant="h5" className={classes.mb}>
						{routes[pathname].title}
					</Typography>
					{children}
				</Paper>
			</Content>
		</Root>
	) : (
		<React.Fragment>{children}</React.Fragment>
	);
};

export default _Layout;
export * from "./routes";
