import { Theme, makeStyles } from "@material-ui/core";
export const useGapsStyle = makeStyles((theme: Theme) => ({
	root: {
		"& > div": {
			marginBottom: theme.spacing(2),
		},
	},
	gaps: {
		"& > *": {
			marginRight: theme.spacing(1),
		},
	},
}));
