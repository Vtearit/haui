import { Pagination } from "@types";
import { useRouter } from "next/router";
import _ from "lodash";

export const useFilter = () => {
	const router = useRouter();

	const filterHandler = ({
		data,
		pagination,
	}: {
		data: any;
		pagination: Pagination;
	}) => {
		console.log({ data });
		const cleanData = _.omitBy(data, (i) => !i);
		const { per_page } = pagination;
		router.push({
			query: {
				...cleanData,
				per_page,
				page: 1,
			},
		});
	};

	return filterHandler;
};
