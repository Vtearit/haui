import React, { useCallback, useMemo, useState } from "react";

import { Typography } from "@material-ui/core";
import { useConfirm } from "material-ui-confirm";
import { useSnackbar } from "notistack";
import { useRouter } from "next/router";

import { Schedule, Timestamp } from "@types";
import { RowId } from "@material-ui/data-grid";
import axios from "axios";
import { SchedulerDateTime } from "@devexpress/dx-react-scheduler";
import moment from "moment";
import RRule from "rrule";

declare interface CrudOptions<R> {
	redirect?: string;
	message: (data: R) => string;
}

export declare interface DeleteHandler {
	(ids: RowId[]): Promise<any>;
}

export const useCreate = <R extends Timestamp>(
	url: string,
	opts?: CrudOptions<R> | undefined
) => {
	const [loading, setLoading] = useState(false);

	const router = useRouter();
	const { enqueueSnackbar } = useSnackbar();

	const createHandler = useCallback(async (formData: any): Promise<R> => {
		setLoading(true);
		try {
			const { data } = await axios.post<R>(url, formData);

			opts?.message &&
				enqueueSnackbar(opts.message(data), { variant: "success" });
			opts?.redirect && router.push(opts.redirect);
			return data;
		} catch (error) {
			throw error.response.data;
		} finally {
			setLoading(false);
		}
	}, []);

	return useMemo(() => {
		return { loading, setLoading, createHandler };
	}, [loading]);
};

export function useUpdate<T>(url: string, opts?: CrudOptions<T>) {
	const [loading, setLoading] = useState(false);

	const router = useRouter();
	const { enqueueSnackbar } = useSnackbar();

	const updateHandler = useCallback(async (formData: any): Promise<T> => {
		setLoading(true);
		try {
			const { data } = await axios.put<T>(url, formData);

			opts?.message &&
				enqueueSnackbar(opts.message(data), { variant: "success" });
			opts?.redirect && router.push(opts.redirect);
			return data;
		} catch (error) {
			throw error.response.data;
		} finally {
			setLoading(false);
		}
	}, []);

	return useMemo(() => {
		return { loading, updateHandler };
	}, [loading]);
}

declare interface ScheduleFormData {
	id?: string;
	user_id: string;
	lab_id: string;
	class_id?: string;
	subject_id?: string;
	allDay: boolean;
	startDate: SchedulerDateTime;
	endDate: SchedulerDateTime;
	rRule?: any;
	isRecurrence: boolean;
}

export const useCreateOrUpdateSchedule = (
	opts?: CrudOptions<number | Schedule>
) => {
	const [loading, setLoading] = useState(false);

	const router = useRouter();
	const { enqueueSnackbar } = useSnackbar();

	const createOrUpdateHandler = useCallback(
		async ({
			id,
			startDate,
			endDate,
			rRule,
			isRecurrence,
			...formData
		}: ScheduleFormData): Promise<number | Schedule> => {
			setLoading(true);
			try {
				let resData: Schedule | number = -1;

				const mysqlFormat = "YYYY-MM-DD HH:mm:ss";
				const _data = {
					id,
					startDate: moment(startDate).format(mysqlFormat),
					endDate: moment(endDate).format(mysqlFormat),
					rRule: isRecurrence
						? RRule.optionsToString({
								freq: rRule.freq,
								interval: rRule.interval,
								count: rRule.count,
								until: rRule.until,
								byweekday:
									rRule.freq === RRule.WEEKLY ? rRule.byweekday.sort() : [],
						  })
						: null,
					...formData,
				};

				if (id) {
					const { data } = await axios.put<number>(`/schedules/${id}`, _data);
					resData = data;
				} else {
					const { data } = await axios.post<Schedule>("/schedules", _data);
					resData = data;
				}

				opts?.message &&
					enqueueSnackbar(opts.message(resData), { variant: "success" });
				opts?.redirect && router.push(opts.redirect);

				return resData;
			} catch (error) {
				throw error.response.data;
			} finally {
				setLoading(false);
			}
		},
		[]
	);

	return useMemo(() => {
		return { loading, createOrUpdateHandler };
	}, [loading]);
};

export function useDelete(
	resource: string,
	opts?: CrudOptions<number> | undefined
) {
	const confirm = useConfirm();

	const { push, asPath } = useRouter();
	const { enqueueSnackbar } = useSnackbar();

	const [loading, setLoading] = useState(false);

	const deleteHandler: DeleteHandler = async (ids) => {
		try {
			await confirm({
				title: "Notification",
				description: (
					<>
						<Typography variant="button">
							Are you sure want to delete:
						</Typography>
						<pre>{JSON.stringify(ids, null, 3)}</pre>
					</>
				),
			});
			setLoading(true);
			let deleted = 0;
			for await (const id of ids) {
				const { data } = await axios.delete(`/${resource}/${id}`);
				if (data) {
					deleted++;
				}
			}
			opts?.message &&
				enqueueSnackbar(opts.message(deleted), { variant: "info" });
			push(opts?.redirect || asPath);
		} catch (err) {
			throw err?.response.data || err;
		} finally {
			setLoading(false);
		}
	};

	return useMemo(() => {
		return { loading, deleteHandler };
	}, [loading, deleteHandler]);
}

export async function useCollection<T>(url: string, query?: any): Promise<T> {
	try {
		const { data } = await axios.get<T>(url, {
			params: query,
		});
		return data;
	} catch (error) {
		throw error.response.data;
	}
}

export const useGetOne = async <T extends Timestamp>(
	url: string,
	query?: any
): Promise<T> => {
	try {
		const { data } = await axios.get<T>(url, {
			params: query,
		});
		return data;
	} catch (error) {
		throw error.response.data;
	}
};
