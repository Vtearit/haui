import { createMuiTheme } from "@material-ui/core/styles";
import { blue, pink } from "@material-ui/core/colors";

// Create a theme instance.
export default createMuiTheme({
	palette: {
		primary: {
			main: blue[500],
		},
		secondary: {
			main: pink["A400"],
		},
	},

	overrides: {
		MuiCssBaseline: {
			"@global": {},
		},
		MuiTabs: {
			// @ts-ignore
			vertical: {
				"& .MuiTab-root": {
					borderBottom: "1px dashed #ccc",
				},
			},
		},

		MuiTab: {
			root: {
				"& + MuiTab-root": {
					border: "1px dashed #ccc",
				},
			},
			labelIcon: {
				minHeight: 56,
			},
		},
	},

	props: {
		MuiTextField: {
			size: "small",
			variant: "outlined",
			InputLabelProps: {
				shrink: true,
			},
			fullWidth: true,
		},
		MuiCheckbox: {
			size: "small",
		},
		MuiButton: {
			size: "small",
		},
		MuiLink: {
			underline: "none",
		},
		// MuiPaper: {
		// 	variant: "outlined",
		// },

		MuiIconButton: {
			color: "primary",
		},
	},

	typography: {
		fontSize: 13,
		h1: {
			fontWeight: 700,
		},
		h2: {
			fontWeight: 700,
		},
		h3: {
			fontWeight: 700,
		},
		h4: {
			fontWeight: 700,
		},
		h5: {
			fontWeight: 700,
		},
		h6: {
			fontWeight: 700,
		},
	},
});
