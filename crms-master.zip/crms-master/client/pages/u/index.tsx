export interface DashboardProps {}

const Dashboard: React.FunctionComponent<DashboardProps> = () => {
	return <h1>Dashboard</h1>;
};

Dashboard.displayName = "Dashboard";

export default Dashboard;
