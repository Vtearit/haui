import * as React from "react";

import { TextField } from "@material-ui/core";
import { useForm } from "react-hook-form";

import { Class } from "@types";
import { useGapsStyle, useCreate } from "@hooks";
import { SubmitButton } from "@components";

const CreateClassPage = () => {
	const classes = useGapsStyle();
	const { register, handleSubmit, errors, setError, reset } = useForm();

	const { loading, createHandler } = useCreate<Class>("/classes", {
		message: ({ id, created_at }) => `id: ${id} created at ${created_at}`,
		redirect: "/u/classes",
	});
	const createLab = async (data: any) => {
		try {
			await createHandler(data);
		} catch (err) {
			for (const key in err) {
				setError(key, {
					type: "manual",
					message: err[key],
				});
			}
		}
	};

	return (
		<form
			className={classes.root}
			onSubmit={handleSubmit(createLab)}
			style={{ width: "45%" }}
		>
			{[
				{ name: "id", label: "Id" },
				{ name: "name", label: "Name" },
				{ name: "school_start", label: "Year Start" },
				{ name: "school_end", label: "Year End" },
				{ name: "note", label: "Note", multiline: true, rows: 4 },
			].map(({ name, ...props }, key) => (
				<TextField
					{...props}
					key={key}
					name={name}
					inputRef={register}
					error={Boolean(errors[name])}
					helperText={errors[name]?.message || ""}
				/>
			))}

			<SubmitButton loading={loading} resource="classes" resetHandler={reset} />
		</form>
	);
};

export default CreateClassPage;
