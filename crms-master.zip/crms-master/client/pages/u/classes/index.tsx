import * as React from "react";

import { GetServerSideProps, NextPage } from "next";

import { RowId } from "@material-ui/data-grid";

import { FilterBox, MyDatagrid, ResourceActions } from "@components";

import { useGapsStyle, useCollection, useDelete } from "@hooks";
import { Classes } from "@types";

const ClassesPage: NextPage<Classes> = ({ rows, pagination, sort }) => {
	const classes = useGapsStyle();

	const [selected, setSelected] = React.useState<RowId[]>([]);
	const { loading, deleteHandler } = useDelete("classes", {
		message: (deleted) => `${deleted} classes were removed`,
	});

	return (
		<div className={classes.root}>
			<ResourceActions
				resource="classes"
				disabledDelete={!selected.length}
				loading={loading}
				onDelete={() => deleteHandler(selected).then(() => setSelected([]))}
			/>
			<FilterBox
				fields={[
					{ name: "id", md: 2 },
					{ name: "name", md: 4 },
					{ name: "school_start", md: 1 },
					{ name: "school_end", md: 1 },
					{ md: 4 },
					{ name: "created_at", md: 3, type: "date" },
					{ name: "updated_at", md: 3, type: "date" },
				]}
				pagination={pagination}
			/>

			<MyDatagrid
				rows={rows}
				paginate={pagination}
				sort={sort}
				resource="classes"
				onSelectionChange={({ rowIds }) => setSelected(rowIds)}
				deleteHandler={deleteHandler}
				columns={[
					{ field: "id", headerName: "ID", width: 130 },
					{ field: "name", headerName: "Name", width: 170 },
					{ field: "school_start", headerName: "Start", width: 70 },
					{ field: "school_end", headerName: "End", width: 70 },
					{
						field: "note",
						headerName: "Note",
						description: "This column is not sortable.",
						sortable: false,
						width: 170,
					},
				]}
			/>
		</div>
	);
};

export const getServerSideProps: GetServerSideProps<Classes> = async (ctx) => {
	const props = await useCollection<Classes>("/classes", ctx.query);

	return {
		props,
	};
};

export default ClassesPage;
