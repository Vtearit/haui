import * as React from "react";

import { TextField } from "@material-ui/core";

import { useRouter } from "next/router";
import { useForm } from "react-hook-form";

import { Class } from "@types";
import { useGapsStyle, useGetOne, useUpdate } from "@hooks";
import { GetServerSideProps, NextPage } from "next";
import { SubmitButton } from "@components";

const EditClass: NextPage<EditClassPageProps> = ({ defaultValues }) => {
	const classes = useGapsStyle();
	const { query } = useRouter();
	const { register, handleSubmit, reset, errors, setError } = useForm({
		defaultValues,
	});

	const { loading, updateHandler } = useUpdate<number>(`/classes/${query.id}`, {
		message: () => `${query.id} was updated successfully`,
		redirect: "/u/classes",
	});

	const updateLab = async (data: any) => {
		try {
			await updateHandler(data);
		} catch (err) {
			for (const key in err) {
				//@ts-ignore
				setError(key, {
					type: "manual",
					message: err[key],
				});
			}
		}
	};

	return (
		<form
			className={classes.root}
			onSubmit={handleSubmit(updateLab)}
			style={{ width: "45%" }}
		>
			{[
				{ name: "id", label: "Id" },
				{ name: "name", label: "Name" },
				{ name: "school_start", label: "Year Start" },
				{ name: "school_end", label: "Year End" },
				{ name: "note", label: "Note", multiline: true, rows: 4 },
			].map(({ name, ...props }, key) => (
				<TextField
					{...props}
					key={key}
					name={name}
					inputRef={register}
					// @ts-ignore
					error={Boolean(errors[name])}
					// @ts-ignore
					helperText={errors[name]?.message || ""}
				/>
			))}
			<SubmitButton loading={loading} resource="classes" resetHandler={reset} />
		</form>
	);
};

declare interface EditClassPageProps {
	defaultValues: Class;
}

export const getServerSideProps: GetServerSideProps<EditClassPageProps> = async ({
	query,
}) => {
	const defaultValues = await useGetOne<Class>(`/classes/${query.id}`);

	return {
		props: {
			defaultValues,
		},
	};
};

export default EditClass;
