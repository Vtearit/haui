import * as React from "react";

import { useRouter } from "next/router";
import { GetServerSideProps, NextPage } from "next";

import _ from "lodash";

import { ModelDetail } from "@components";
import { useGetOne, useGapsStyle } from "@hooks";
import { Class } from "@types";

const ShowLab: NextPage<Class> = (data) => {
	const classes = useGapsStyle();
	const { query } = useRouter();

	return (
		<div className={classes.root}>
			<ModelDetail resource="classes" data={data} id={query.id as string} />
		</div>
	);
};

export const getServerSideProps: GetServerSideProps<Class> = async (ctx) => {
	const props = await useGetOne<Class>(`/classes/${ctx.query.id}`);

	return {
		props,
	};
};
export default ShowLab;
