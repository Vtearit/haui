import * as React from "react";

import { TextField, MenuItem } from "@material-ui/core";
import { Controller, useForm } from "react-hook-form";

import { User } from "@types";
import { useGapsStyle, useCreate } from "@hooks";
import { SubmitButton } from "@components";

const CreateUserPage = () => {
	const classes = useGapsStyle();
	const {
		register,
		handleSubmit,
		errors,
		setError,
		reset,
		control,
		watch,
	} = useForm();
	const passwordRef = React.useRef();
	passwordRef.current = watch("password", "");

	const { loading, createHandler } = useCreate<User>("/users", {
		message: ({ id, created_at }) => `id: ${id} created at ${created_at}`,
		redirect: "/u/users",
	});
	const createLab = async ({ confirmm, ...data }: any) => {
		try {
			await createHandler(data);
		} catch (err) {
			for (const key in err) {
				setError(key, {
					type: "manual",
					message: err[key],
				});
			}
		}
	};

	return (
		<form
			className={classes.root}
			onSubmit={handleSubmit(createLab)}
			style={{ width: "45%" }}
			autoComplete="off"
		>
			<TextField
				label="Id"
				name="id"
				error={Boolean(errors?.id)}
				helperText={errors?.id?.message || ""}
				inputRef={register({
					required: { value: true, message: "Id is required" },
				})}
			/>
			<TextField
				label="Full Name"
				name="full_name"
				error={Boolean(errors?.full_name)}
				helperText={errors?.full_name?.message || ""}
				inputRef={register({
					required: { value: true, message: "Full name is required" },
				})}
			/>
			<TextField
				label="Email"
				name="email"
				error={Boolean(errors?.email)}
				helperText={errors?.email?.message || ""}
				inputRef={register({
					required: {
						value: true,
						message: "Email is required",
					},
					pattern: {
						value: emailPattern,
						message: "Invalid Email",
					},
				})}
			/>
			<TextField
				label="Password"
				name="password"
				error={Boolean(errors?.password)}
				helperText={errors?.password?.message || ""}
				inputRef={register({
					required: {
						value: true,
						message: "Password is required",
					},
					minLength: {
						value: 6,
						message: "Password must have at least 6 characters",
					},
				})}
				type="password"
			/>
			<TextField
				label="Confirm password"
				name="confirm"
				error={Boolean(errors?.confirm)}
				helperText={errors?.confirm?.message || ""}
				inputRef={register({
					validate: (value) =>
						value === passwordRef.current || "Password doesn't match",
				})}
				type="password"
			/>
			<Controller
				name="role"
				control={control}
				render={({ value, onChange }) => (
					<TextField select label="Role" value={value} onChange={onChange}>
						{["Admin", "Teacher", "Employeer"].map((val) => (
							<MenuItem value={val}>{val}</MenuItem>
						))}
					</TextField>
				)}
			/>
			<SubmitButton loading={loading} resource="users" resetHandler={reset} />
		</form>
	);
};
const emailPattern = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

export default CreateUserPage;
