import * as React from "react";

import { GetServerSideProps, NextPage } from "next";

import { RowId } from "@material-ui/data-grid";

import { FilterBox, MyDatagrid, ResourceActions } from "@components";

import { useGapsStyle, useCollection, useDelete } from "@hooks";
import { Users } from "@types";

const LabsPage: NextPage<Users> = ({ rows, pagination, sort }) => {
	const classes = useGapsStyle();

	const [selected, setSelected] = React.useState<RowId[]>([]);
	const { loading, deleteHandler } = useDelete("users", {
		message: (deleted) => `${deleted} users were removed`,
	});

	return (
		<div className={classes.root}>
			<ResourceActions
				resource="users"
				disabledDelete={!selected.length}
				loading={loading}
				onDelete={() => deleteHandler(selected).then(() => setSelected([]))}
			/>
			<FilterBox
				fields={[
					{ name: "id", md: 2 },
					{ name: "full_name", md: 2 },

					{ name: "email", md: 3 },
					{
						name: "role",
						md: 3,
						options: ["Admin", "Teacher", "Employeer"],
					},
					{ md: 2 },
					{ name: "created_at", md: 3, type: "date" },
					{ name: "updated_at", md: 3, type: "date" },
				]}
				pagination={pagination}
			/>

			<MyDatagrid
				rows={rows}
				paginate={pagination}
				sort={sort}
				resource="users"
				onSelectionChange={({ rowIds }) => setSelected(rowIds)}
				deleteHandler={deleteHandler}
				columns={[
					{ field: "id", headerName: "Id" },
					{ field: "full_name", headerName: "Full Name", width: 130 },
					{ field: "email", headerName: "Email", width: 150 },
					{ field: "role", headerName: "Role" },
				]}
			/>
		</div>
	);
};

export const getServerSideProps: GetServerSideProps<Users> = async (ctx) => {
	const props = await useCollection<Users>("/users", ctx.query);

	return {
		props,
	};
};

export default LabsPage;
