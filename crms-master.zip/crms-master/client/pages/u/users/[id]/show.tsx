import * as React from "react";

import { useRouter } from "next/router";
import { GetServerSideProps, NextPage } from "next";

import {
	ViewState,
	EditingState,
	IntegratedEditing,
	Resource,
} from "@devexpress/dx-react-scheduler";
import {
	Scheduler,
	Appointments,
	MonthView,
	WeekView,
	DateNavigator,
	ViewSwitcher,
	AppointmentForm,
	AppointmentTooltip,
	AllDayPanel,
	Resources,
	CurrentTimeIndicator,
	Toolbar,
} from "@devexpress/dx-react-scheduler-material-ui";
import {
	ModelDetail,
	MyOverlay,
	MyLayout,
	MyBasic,
	ToolbarWithLoading,
} from "@components";

import _ from "lodash";
import axios from "axios";
import moment from "moment";

import { User } from "@types";
import { useGetOne, useDelete, useGapsStyle } from "@hooks";
import { Paper, Typography } from "@material-ui/core";

const ShowUserPage: NextPage<ShowUserPageProps> = ({ user, resources }) => {
	const { query } = useRouter();

	const classes = useGapsStyle();
	let { schedules, ...data } = user;

	const { loading, deleteHandler } = useDelete("schedules", {
		message: () => `Schedule is deleted successfuly`,
	});

	if (user.role === "Employeer") {
		const formatter = Intl.NumberFormat("vi-VN", {
			style: "currency",
			currency: "VND",
		});

		const salary = formatter.format(
			schedules?.reduce((total, { totalPay }) => total + totalPay, 0) || 0
		);

		const totalShifts =
			schedules?.reduce((total, { shiftsCount }) => total + shiftsCount, 0) ||
			0;

		data = Object.assign(data, {
			salary,
			totalShifts,
		});
	}

	return (
		<div className={classes.root}>
			<ModelDetail
				resource="users"
				data={data}
				id={query.id as string}
			></ModelDetail>

			<Paper variant="outlined">
				<Scheduler data={schedules} firstDayOfWeek={1}>
					<ViewState defaultCurrentViewName="Week" />
					<EditingState
						onCommitChanges={({ deleted, changed }) => {
							// @ts-ignore
							deleteHandler([deleted || Object.keys(changed)[0]]);
						}}
					/>
					<IntegratedEditing />

					<Toolbar
						{...(loading ? { rootComponent: ToolbarWithLoading } : null)}
					/>

					<MonthView />
					<WeekView cellDuration={120} />
					<ViewSwitcher />
					<DateNavigator />
					<Appointments
						appointmentContentComponent={({ data, ...rest }) => (
							<Appointments.AppointmentContent
								{...rest}
								data={data}
								style={{ flexDirection: "column" }}
							>
								<Typography variant="button">
									{data.lab_id}
									<br />
									{data?.subject_id || data?.pay + "/h"}
								</Typography>
								<Typography variant="caption">
									{moment(data.startDate).format("HH:mm") +
										" - " +
										moment(data.endDate).format("HH:mm")}
								</Typography>
							</Appointments.AppointmentContent>
						)}
					/>
					<AllDayPanel />
					<Resources data={resources} />
					<AppointmentTooltip showCloseButton showOpenButton showDeleteButton />
					<AppointmentForm
						overlayComponent={MyOverlay}
						layoutComponent={MyLayout}
						basicLayoutComponent={MyBasic}
					/>
					<CurrentTimeIndicator shadePreviousCells shadePreviousAppointments />
				</Scheduler>
			</Paper>
		</div>
	);
};

declare interface ShowUserPageProps {
	user: User;
	resources: Resource[];
}
export const getServerSideProps: GetServerSideProps<ShowUserPageProps> = async (
	ctx
) => {
	const [user, { data: resources }] = await Promise.all([
		useGetOne<User>(`/users/${ctx.query.id}`),
		axios.get<Resource[]>("/schedules?resources"),
	]);

	return {
		props: { user, resources },
	};
};
export default ShowUserPage;
