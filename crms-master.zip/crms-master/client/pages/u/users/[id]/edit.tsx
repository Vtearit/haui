import * as React from "react";

import {
	TextField,
	MenuItem,
	Tooltip,
	InputAdornment,
} from "@material-ui/core";
import InfoIcon from "@material-ui/icons/InfoOutlined";

import { useRouter } from "next/router";
import { useForm, Controller } from "react-hook-form";

import { User } from "@types";
import { useGapsStyle, useGetOne, useUpdate } from "@hooks";
import { GetServerSideProps, NextPage } from "next";
import { SubmitButton } from "@components";
import _ from "lodash";

const EditUser: NextPage<EditUserPageProps> = ({ defaultValues }) => {
	const classes = useGapsStyle();
	const { query } = useRouter();
	const {
		register,
		handleSubmit,
		reset,
		errors,
		setError,
		control,
		watch,
	} = useForm({
		defaultValues,
	});
	const passwordRef = React.useRef();
	// @ts-ignore
	passwordRef.current = watch("password", "");

	const { loading, updateHandler } = useUpdate<number>(`/users/${query.id}`, {
		message: () => "User was updated successfully",
		redirect: "/u/users",
	});

	const updateUser = async ({ confirm, ...data }: any) => {
		try {
			await updateHandler(_.omitBy(data, (i) => !i));
		} catch (err) {
			for (const key in err) {
				//@ts-ignore
				setError(key, {
					type: "manual",
					message: err[key],
				});
			}
		}
	};

	return (
		<form
			className={classes.root}
			onSubmit={handleSubmit(updateUser)}
			style={{ width: "45%" }}
			autoComplete="off"
		>
			<TextField
				label="Id"
				name="id"
				error={Boolean(errors?.id)}
				helperText={errors?.id?.message || ""}
				inputRef={register({
					required: { value: true, message: "Id is required" },
				})}
			/>
			<TextField
				label="Full Name"
				name="full_name"
				error={Boolean(errors?.full_name)}
				helperText={errors?.full_name?.message || ""}
				inputRef={register({
					required: { value: true, message: "Full name is required" },
				})}
			/>
			<TextField
				label="Email"
				name="email"
				error={Boolean(errors?.email)}
				helperText={errors?.email?.message || ""}
				inputRef={register({
					required: {
						value: true,
						message: "Email is required",
					},
					pattern: {
						value: emailPattern,
						message: "Invalid Email",
					},
				})}
			/>
			<TextField
				label="Password"
				name="password"
				// @ts-ignore
				error={Boolean(errors?.password)}
				// @ts-ignore
				helperText={errors?.password?.message || ""}
				inputRef={register({
					minLength: {
						value: 6,
						message: "Password must have at least 6 characters",
					},
				})}
				type="password"
				InputProps={{
					endAdornment: (
						<InputAdornment position="end">
							<Tooltip title="If you don't want change password, leave this empty">
								<InfoIcon />
							</Tooltip>
						</InputAdornment>
					),
				}}
			/>

			<TextField
				label="Confirm password"
				name="confirm"
				// @ts-ignore
				error={Boolean(errors?.confirm)}
				// @ts-ignore
				helperText={errors?.confirm?.message || ""}
				inputRef={register({
					validate: (value) =>
						value === passwordRef.current || "The password is not matched",
				})}
				type="password"
			/>

			<Controller
				name="role"
				control={control}
				render={({ value, onChange }) => (
					<TextField select label="Role" value={value} onChange={onChange}>
						{["Admin", "Teacher", "Employeer"].map((val) => (
							<MenuItem value={val}>{val}</MenuItem>
						))}
					</TextField>
				)}
			/>
			<SubmitButton loading={loading} resource="users" resetHandler={reset} />
		</form>
	);
};

declare interface EditUserPageProps {
	defaultValues: User;
}
const emailPattern = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

export const getServerSideProps: GetServerSideProps<EditUserPageProps> = async ({
	query,
}) => {
	const defaultValues = await useGetOne<User>(`/users/${query.id}`);

	return {
		props: {
			defaultValues,
		},
	};
};

export default EditUser;
