import * as React from "react";

import { GetServerSideProps, NextPage } from "next";

import { RowId } from "@material-ui/data-grid";

import { FilterBox, MyDatagrid, ResourceActions } from "@components";

import { useGapsStyle, useCollection, useDelete } from "@hooks";
import { Subjects } from "@types";

const LabsPage: NextPage<Subjects> = ({ rows, pagination, sort }) => {
	const classes = useGapsStyle();

	const [selected, setSelected] = React.useState<RowId[]>([]);
	const { loading, deleteHandler } = useDelete("subjects", {
		message: (deleted) => `${deleted} subjects were removed`,
	});

	return (
		<div className={classes.root}>
			<ResourceActions
				resource="subjects"
				disabledDelete={!selected.length}
				loading={loading}
				onDelete={() => deleteHandler(selected).then(() => setSelected([]))}
			/>
			<FilterBox
				fields={[
					{ name: "id", md: 2 },
					{ name: "name", md: 4 },
					{ md: 6 },
					{ name: "created_at", md: 3, type: "date" },
					{ name: "updated_at", md: 3, type: "date" },
				]}
				pagination={pagination}
			/>

			<MyDatagrid
				rows={rows}
				paginate={pagination}
				sort={sort}
				resource="subjects"
				onSelectionChange={({ rowIds }) => setSelected(rowIds)}
				deleteHandler={deleteHandler}
				columns={[
					{ field: "id", headerName: "ID" },
					{ field: "name", headerName: "Name", width: 200 },
					{
						field: "note",
						headerName: "Note",
						description: "This column is not sortable.",
						sortable: false,
						width: 200,
					},
				]}
			/>
		</div>
	);
};

export const getServerSideProps: GetServerSideProps<Subjects> = async (ctx) => {
	const props = await useCollection<Subjects>("/subjects", ctx.query);

	return {
		props,
	};
};

export default LabsPage;
