import * as React from "react";

import { TextField } from "@material-ui/core";
import { useForm } from "react-hook-form";

import { Subject } from "@types";
import { useGapsStyle, useCreate } from "@hooks";
import { SubmitButton } from "@components";

const CreateLabPage = () => {
	const classes = useGapsStyle();
	const { register, handleSubmit, errors, setError, reset } = useForm();

	const { loading, createHandler } = useCreate<Subject>("/subjects", {
		message: ({ id, created_at }) => `id: ${id} created at ${created_at}`,
		redirect: "/u/subjects",
	});
	const createLab = async (data: any) => {
		try {
			await createHandler(data);
		} catch (err) {
			for (const key in err) {
				setError(key, {
					type: "manual",
					message: err[key],
				});
			}
		}
	};

	return (
		<form
			className={classes.root}
			onSubmit={handleSubmit(createLab)}
			style={{ width: "45%" }}
		>
			<TextField
				label="Id"
				name="id"
				inputRef={register}
				error={Boolean(errors?.id)}
				helperText={errors?.id?.message || ""}
			/>
			<TextField
				label="Name"
				name="name"
				inputRef={register}
				helperText={errors?.name?.message || ""}
			/>
			<TextField
				label="Note"
				name="note"
				multiline
				rows={4}
				inputRef={register}
			/>
			<SubmitButton
				loading={loading}
				resource="subjects"
				resetHandler={reset}
			/>
		</form>
	);
};

export default CreateLabPage;
