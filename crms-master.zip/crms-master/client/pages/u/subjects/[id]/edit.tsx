import * as React from "react";

import { TextField } from "@material-ui/core";

import { useRouter } from "next/router";
import { useForm } from "react-hook-form";

import { Subject } from "@types";
import { useGapsStyle, useGetOne, useUpdate } from "@hooks";
import { GetServerSideProps, NextPage } from "next";
import { SubmitButton } from "@components";

const EditSubject: NextPage<EditSubjectPageProps> = ({ defaultValues }) => {
	const classes = useGapsStyle();
	const { query } = useRouter();
	const { register, handleSubmit, reset, errors, setError } = useForm({
		defaultValues,
	});

	const { loading, updateHandler } = useUpdate<number>(
		`/subjects/${query.id}`,
		{
			message: () => `${query.id} was updated successfully`,
			redirect: "/u/subjects",
		}
	);

	const updateLab = async (data: any) => {
		try {
			await updateHandler(data);
		} catch (err) {
			for (const key in err) {
				//@ts-ignore
				setError(key, {
					type: "manual",
					message: err[key],
				});
			}
		}
	};

	return (
		<form
			className={classes.root}
			onSubmit={handleSubmit(updateLab)}
			style={{ width: "45%" }}
		>
			<TextField
				label="Id"
				name="id"
				inputRef={register}
				error={Boolean(errors?.id)}
				helperText={errors?.id?.message || ""}
			/>
			<TextField
				label="Name"
				name="name"
				inputRef={register}
				helperText={errors?.name?.message || ""}
			/>
			<TextField
				label="Note"
				name="note"
				multiline
				rows={4}
				inputRef={register}
			/>
			<SubmitButton
				loading={loading}
				resource="subjects"
				resetHandler={reset}
			/>
		</form>
	);
};

declare interface EditSubjectPageProps {
	defaultValues: Subject;
}

export const getServerSideProps: GetServerSideProps<EditSubjectPageProps> = async ({
	query,
}) => {
	const defaultValues = await useGetOne<Subject>(`/subjects/${query.id}`);

	return {
		props: {
			defaultValues,
		},
	};
};

export default EditSubject;
