import * as React from "react";

import { TextField } from "@material-ui/core";

import { Autocomplete } from "@material-ui/lab";

import { useRouter } from "next/router";
import { Controller, useForm } from "react-hook-form";

import axios from "axios";
import _ from "lodash";
import { Lab } from "@types";
import { useCollection, useGapsStyle, useGetOne, useUpdate } from "@hooks";
import { SubmitButton } from "@components";

import { GetServerSideProps, NextPage } from "next";
import { useSnackbar } from "notistack";

const fields = [
	{ label: "Id", name: "id", required: true },
	{ label: "Building", name: "building", required: true },
	{ label: "Room", name: "room", required: true, type: "number" },
	{ label: "Note", name: "note", multiline: true, rows: 4, required: false },
];

const EditLab: NextPage<ShowLabPageProps> = ({
	defaultValues,
	ComputersWithNullLab,
}) => {
	const classes = useGapsStyle();
	const { query, push } = useRouter();
	const { register, handleSubmit, reset, errors, setError, control } = useForm({
		defaultValues,
	});

	const { loading, updateHandler } = useUpdate<number>(`/labs/${query.id}`);
	const { enqueueSnackbar } = useSnackbar();

	const updateLab = async ({ computer_ids, ...data }: any) => {
		try {
			await updateHandler(data);
			await axios.post(`/labs/${data.id}/computers`, computer_ids);
			enqueueSnackbar("Lab was updated successfully", {
				variant: "success",
			});

			push("/u/labs");
		} catch (err) {
			for (const key in err) {
				setError(key, {
					type: "manual",
					message: err[key],
				});
			}
		}
	};

	return (
		<form
			className={classes.root}
			onSubmit={handleSubmit(updateLab)}
			style={{ width: "45%" }}
		>
			{fields.map(({ label, required, ...props }) => (
				<TextField
					{...props}
					label={label}
					inputRef={register({
						required: {
							value: required,
							message: `${label} is required`,
						},
					})}
					// @ts-ignore
					error={Boolean(errors[props.name])}
					// @ts-ignore
					helperText={errors[props.name]?.message || ""}
				/>
			))}

			<Controller
				name="computer_ids"
				control={control}
				render={({ value, onChange }) => (
					<Autocomplete
						multiple
						filterSelectedOptions
						value={value}
						onChange={(_, val) => onChange(val)}
						options={ComputersWithNullLab}
						renderInput={(param) => (
							<TextField {...param} label="Computer Ids" />
						)}
					/>
				)}
			/>

			<SubmitButton loading={loading} resource="labs" resetHandler={reset} />
		</form>
	);
};

declare interface ShowLabPageProps {
	defaultValues: Lab & { computer_ids: string[] };
	ComputersWithNullLab: string[];
}

export const getServerSideProps: GetServerSideProps<ShowLabPageProps> = async ({
	query,
}) => {
	const labId = query.id;

	const [lab, computer_ids, ComputersWithNullLab] = await Promise.all([
		useGetOne<Lab>(`/labs/${labId}`),
		useCollection<number[]>(`/labs/${labId}/computers?ids`).then((c) =>
			c.map((r) => r.toString())
		),
		useCollection<number[]>("/computers?available").then((c) =>
			c.map((r) => r.toString())
		),
	]);

	return {
		props: {
			defaultValues: {
				...lab,
				computer_ids,
			},
			ComputersWithNullLab: [...ComputersWithNullLab, ...computer_ids],
		},
	};
};
export default EditLab;
