import * as React from "react";

import { useRouter } from "next/router";
import { GetServerSideProps, NextPage } from "next";

import _ from "lodash";

import { ModelDetail, StatusBar, MyDatagrid } from "@components";
import { useCollection, useGetOne, useGapsStyle } from "@hooks";
import { Computers, Lab } from "@types";

const ShowLab: NextPage<ShowLabPageProps> = ({
	lab,
	computers: { rows, pagination, sort },
}) => {
	const classes = useGapsStyle();
	const { query } = useRouter();

	return (
		<div className={classes.root}>
			<ModelDetail resource="labs" data={lab} id={query.id as string} />
			<MyDatagrid
				rows={rows}
				paginate={pagination}
				sort={sort}
				columns={[
					{ field: "id", headerName: "ID" },
					{
						field: "status",
						headerName: "Status",
						type: "number",
						width: 120,
						renderCell: ({ value }) => <StatusBar value={value}></StatusBar>,
					},
					{
						field: "note",
						headerName: "Note",
						description: "This column is not sortable.",
						sortable: false,
						width: 250,
					},
				]}
			/>
		</div>
	);
};

declare interface ShowLabPageProps {
	lab: Lab;
	computers: Computers;
}

export const getServerSideProps: GetServerSideProps<ShowLabPageProps> = async ({
	query,
}) => {
	const { id: labId, ...params } = query;

	const lab = await useGetOne<Lab>(`/labs/${labId}`);
	const computers = await useCollection<Computers>(
		`/labs/${labId}/computers`,
		params
	);

	return {
		props: {
			lab,
			computers,
		},
	};
};
export default ShowLab;
