import * as React from "react";

import { GetServerSideProps, NextPage } from "next";

import { RowId } from "@material-ui/data-grid";

import { MyDatagrid, ResourceActions, FilterBox } from "@components";

import { useGapsStyle, useCollection, useDelete } from "@hooks";
import { Labs } from "@types";

const LabsPage: NextPage<Labs> = ({ rows, pagination, sort }) => {
	const classes = useGapsStyle();

	const [selected, setSelected] = React.useState<RowId[]>([]);
	const { loading, deleteHandler } = useDelete("labs", {
		message: (deleted) => `${deleted} labs were removed`,
	});

	return (
		<div className={classes.root}>
			<ResourceActions
				resource="labs"
				disabledDelete={!selected.length}
				loading={loading}
				onDelete={() => deleteHandler(selected).then(() => setSelected([]))}
			/>
			<FilterBox
				fields={[
					{ name: "id", md: 4 },
					{ name: "building", md: 1 },
					{ name: "room", md: 1, type: "number" },
					{ md: 6 },
					{ name: "created_at", md: 3, type: "date" },
					{ name: "updated_at", md: 3, type: "date" },
				]}
				pagination={pagination}
			/>

			<MyDatagrid
				paginate={pagination}
				sort={sort}
				resource="labs"
				onSelectionChange={({ rowIds }) => setSelected(rowIds)}
				deleteHandler={deleteHandler}
				rows={rows}
				columns={[
					{ field: "id", headerName: "ID" },
					{ field: "building", headerName: "Building" },
					{
						field: "room",
						headerName: "Room",
						width: 70,
					},
					{
						field: "note",
						headerName: "Note",
						description: "This column is not sortable.",
						sortable: false,
						width: 200,
					},
				]}
			/>
		</div>
	);
};

export const getServerSideProps: GetServerSideProps<Labs> = async (ctx) => {
	const props = await useCollection<Labs>("/labs", ctx.query);

	return {
		props,
	};
};

export default LabsPage;
