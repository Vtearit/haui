import * as React from "react";

import { TextField } from "@material-ui/core";

import { Autocomplete } from "@material-ui/lab";

import { useRouter } from "next/router";
import { Controller, useForm } from "react-hook-form";

import axios from "axios";
import { Lab } from "@types";
import { useCollection, useGapsStyle, useCreate } from "@hooks";
import { SubmitButton } from "@components";
import { GetServerSideProps, NextPage } from "next";
import { useSnackbar } from "notistack";

const fields = [
	{ label: "Id", name: "id", required: true },
	{ label: "Building", name: "building", required: true },
	{ label: "Room", name: "room", required: true, type: "number" },
	{ label: "Note", name: "note", multiline: true, rows: 4, required: false },
];

const CreateLabPage: NextPage<CreateLabProps> = ({ computerWithNullLab }) => {
	const classes = useGapsStyle();
	const router = useRouter();
	const {
		register,
		handleSubmit,
		reset,
		errors,
		setError,
		control,
	} = useForm();

	const { loading, createHandler } = useCreate<Lab>("/labs");
	const { enqueueSnackbar } = useSnackbar();

	const createLab = async ({ computer_ids, ...labData }: any) => {
		try {
			const { id, created_at } = await createHandler(labData);
			let msg = `id: ${id} created at ${created_at} `;

			if (computer_ids) {
				const { data } = await axios.post<number>(
					`/labs/${id}/computers`,
					computer_ids
				);
				msg += `with ${data} computers`;
			}

			enqueueSnackbar(msg, { variant: "success" });
			router.push("/u/labs");
		} catch (err) {
			for (const key in err) {
				setError(key, {
					type: "manual",
					message: err[key],
				});
			}
		}
	};

	return (
		<form
			className={classes.root}
			onSubmit={handleSubmit(createLab)}
			style={{ width: "45%" }}
		>
			{fields.map(({ label, required, ...props }) => (
				<TextField
					{...props}
					label={label}
					inputRef={register({
						required: {
							value: required,
							message: `${label} is required`,
						},
					})}
					error={Boolean(errors[props.name])}
					helperText={errors[props.name]?.message || ""}
				/>
			))}

			<Controller
				name="computer_ids"
				control={control}
				defaultValue={[]}
				render={({ value, onChange }) => (
					<Autocomplete
						multiple
						filterSelectedOptions
						value={value}
						onChange={(_, val) => onChange(val)}
						options={computerWithNullLab}
						getOptionLabel={(o) => String(o)}
						renderInput={(param) => (
							<TextField {...param} label="Avaiable Computer Ids" />
						)}
					/>
				)}
			/>

			<SubmitButton loading={loading} resource="labs" resetHandler={reset} />
		</form>
	);
};

declare interface CreateLabProps {
	computerWithNullLab: number[];
}

export const getServerSideProps: GetServerSideProps<CreateLabProps> = async () => {
	const computerWithNullLab = await useCollection<number[]>(
		"/computers?available",
		{
			select: "id",
		}
	);

	return {
		props: {
			computerWithNullLab,
		},
	};
};

export default CreateLabPage;
