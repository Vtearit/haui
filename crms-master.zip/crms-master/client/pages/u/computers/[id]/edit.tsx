import * as React from "react";

import { TextField, InputAdornment } from "@material-ui/core";

import { Autocomplete } from "@material-ui/lab";

import { GetServerSideProps, NextPage } from "next";
import { useRouter } from "next/router";

import { useForm, Controller } from "react-hook-form";
import _ from "lodash";

import { Computer } from "@types";
import { useCollection, useGapsStyle, useGetOne, useUpdate } from "@hooks";
import { SubmitButton } from "@components";

const EditComputer: NextPage<EditComputerProps> = ({
	labIds,
	defaultValues,
}) => {
	const classes = useGapsStyle();
	const { query } = useRouter();

	const { register, control, handleSubmit, reset, errors, setError } = useForm({
		defaultValues,
	});

	const { loading, updateHandler } = useUpdate<number>(
		`/computers/${query.id}`,
		{
			message: () => `${query.id} was updated successfully`,
			redirect: "/u/computers",
		}
	);

	const editComputer = async (data: any) => {
		try {
			await updateHandler(_.omitBy(data, (p) => !p));
		} catch (err) {
			for (const key in err) {
				//@ts-ignore
				setError(key, {
					type: "manual",
					message: err[key],
				});
			}
		}
	};

	return (
		<form
			className={classes.root}
			onSubmit={handleSubmit(editComputer)}
			style={{ width: "45%" }}
		>
			<TextField
				label="Status"
				name="status"
				type="number"
				inputProps={{ step: "0.01" }}
				InputProps={{
					endAdornment: <InputAdornment position="end">%</InputAdornment>,
				}}
				inputRef={register({
					required: {
						value: true,
						message: "Status is required",
					},
					min: {
						value: 0,
						message: "Status must large than 0",
					},
					max: {
						value: 100,
						message: "Status must lower than 100",
					},
				})}
				error={Boolean(errors?.status)}
				helperText={errors?.status?.message || ""}
			/>

			<TextField
				label="Note"
				name="note"
				multiline
				rows={4}
				inputRef={register}
			/>

			<Controller
				name="lab_id"
				control={control}
				render={({ value, onChange }) => (
					<Autocomplete
						options={labIds}
						value={value}
						onChange={(_, val) => onChange(val)}
						renderInput={(params) => <TextField {...params} label="Lab Id" />}
					/>
				)}
			/>

			<SubmitButton
				loading={loading}
				resource="computers"
				resetHandler={reset}
			/>
		</form>
	);
};

declare interface EditComputerProps {
	defaultValues: Computer;
	labIds: string[];
}

export const getServerSideProps: GetServerSideProps<EditComputerProps> = async (
	ctx
) => {
	// avatar labs
	const defaultValues = await useGetOne<Computer>(`/computers/${ctx.query.id}`);
	const labIds = await useCollection<string[]>("/labs?ids");

	return {
		props: {
			defaultValues,
			labIds,
		},
	};
};

export default EditComputer;
