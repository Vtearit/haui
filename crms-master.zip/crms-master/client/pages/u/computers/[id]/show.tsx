import * as React from "react";

import { GetServerSideProps, NextPage } from "next";

import { ModelDetail } from "@components";

import { useGetOne, useGapsStyle } from "@hooks";
import { Computer } from "@types";
import _ from "lodash";
import { useRouter } from "next/router";

const ShowLab: NextPage<Computer> = (computer) => {
	const classes = useGapsStyle();

	const { query } = useRouter();

	return (
		<div className={classes.root}>
			<ModelDetail
				resource="computers"
				data={computer}
				id={query.id as string}
			/>
		</div>
	);
};

export const getServerSideProps: GetServerSideProps<Computer> = async (ctx) => {
	const props = await useGetOne<Computer>(`/computers/${ctx.query.id}`);

	return {
		props,
	};
};
export default ShowLab;
