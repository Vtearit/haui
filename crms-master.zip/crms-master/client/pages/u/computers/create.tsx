import * as React from "react";

import { TextField, InputAdornment } from "@material-ui/core";

import { GetServerSideProps, NextPage } from "next";
import { useForm, Controller } from "react-hook-form";

import { Computer } from "@types";
import { useCreate, useGapsStyle, useCollection } from "@hooks";
import { SubmitButton } from "@components";

import { Autocomplete } from "@material-ui/lab";

const CreateComputer: NextPage<CreatePageProps> = ({ labIds }) => {
	const classes = useGapsStyle();

	const {
		register,
		control,
		handleSubmit,
		errors,
		setError,
		reset,
	} = useForm();

	const { loading, createHandler } = useCreate<Computer>("/computers", {
		message: ({ id, created_at }) => `id: ${id} created at ${created_at}`,
		redirect: "/u/computers",
	});

	const createComputer = async (data: any) => {
		try {
			await createHandler(data);
		} catch (err) {
			for (const key in err) {
				setError(key, {
					type: "manual",
					message: err[key],
				});
			}
		}
	};

	return (
		<form
			className={classes.root}
			onSubmit={handleSubmit(createComputer)}
			style={{ width: "45%" }}
		>
			<TextField
				label="Status"
				name="status"
				type="number"
				inputProps={{ step: "0.01" }}
				InputProps={{
					endAdornment: <InputAdornment position="end">%</InputAdornment>,
				}}
				inputRef={register({
					required: {
						value: true,
						message: "Status is required",
					},
					min: {
						value: 0,
						message: "Status must large than 0",
					},
					max: {
						value: 100,
						message: "Status must lower than 100",
					},
				})}
				error={Boolean(errors?.status)}
				helperText={errors?.status?.message || ""}
			/>

			<TextField
				label="Note"
				name="note"
				multiline
				rows={4}
				inputRef={register}
			/>

			<Controller
				name="lab_id"
				control={control}
				defaultValue={null}
				render={({ value, onChange }) => (
					<Autocomplete
						options={labIds}
						value={value}
						onChange={(_, val) => onChange(val)}
						renderInput={(params) => <TextField {...params} label="Lab Id" />}
					/>
				)}
			/>

			<SubmitButton
				loading={loading}
				resource="computers"
				resetHandler={reset}
			/>
		</form>
	);
};

declare interface CreatePageProps {
	labIds: string[];
}

export const getServerSideProps: GetServerSideProps<CreatePageProps> = async () => {
	const labIds = await useCollection<string[]>("/labs?ids");

	return {
		props: {
			labIds,
		},
	};
};

export default CreateComputer;
