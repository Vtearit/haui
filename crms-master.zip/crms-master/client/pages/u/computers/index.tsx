import React, { useState } from "react";
import { RowId } from "@material-ui/data-grid";
import { GetServerSideProps, NextPage } from "next";

import {
	Link,
	MyDatagrid,
	StatusBar,
	ResourceActions,
	FilterBox,
} from "@components";
import { useDelete, useCollection, useGapsStyle } from "@hooks";
import { Computers } from "@types";

const ComputersPage: NextPage<Computers> = ({ rows, pagination, sort }) => {
	const classes = useGapsStyle();

	const [selected, setSelected] = useState<RowId[]>([]);
	const { loading, deleteHandler } = useDelete("computers", {
		message: (deleted) => `${deleted} computers were removed`,
	});

	return (
		<div className={classes.root}>
			<ResourceActions
				resource="computers"
				loading={loading}
				disabledDelete={!selected.length}
				onDelete={() => deleteHandler(selected).then(() => setSelected([]))}
			/>
			<FilterBox
				fields={[
					{ name: "id", md: 2 },
					{ name: "lab_id", md: 3 },
					{ md: 7 },
					{ name: "created_at", md: 3, type: "date" },
					{ name: "updated_at", md: 3, type: "date" },
				]}
				pagination={pagination}
			/>
			<MyDatagrid
				paginate={pagination}
				sort={sort}
				resource="computers"
				onSelectionChange={({ rowIds }) => setSelected(rowIds)}
				deleteHandler={deleteHandler}
				rows={rows}
				loading={loading}
				columns={[
					{ field: "id", headerName: "ID" },
					{
						field: "status",
						width: 120,
						headerName: "Status",
						renderCell: ({ value }) => <StatusBar value={value} />,
					},
					{
						field: "lab_id",
						description: "Lab Id",
						headerName: "Lab Id",
						renderCell: ({ value }) => (
							<Link href={`/u/labs/${value}/show`}>{value}</Link>
						),
					},
					{
						field: "note",
						headerName: "Note",
						description: "This column is not sortable.",
						sortable: false,
						width: 200,
					},
				]}
			/>
		</div>
	);
};

export const getServerSideProps: GetServerSideProps<Computers> = async (
	ctx
) => {
	const props = await useCollection<Computers>("/computers", ctx.query);

	return {
		props,
	};
};

export default ComputersPage;
