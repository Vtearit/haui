import React from "react";
import { GetServerSideProps, NextPage } from "next";
import { Paper, makeStyles, Theme, Typography } from "@material-ui/core";

import { useCollection, useDelete } from "@hooks";
import { Schedules } from "@types";

import {
	FilterBox,
	MyOverlay,
	MyLayout,
	MyBasic,
	ToolbarWithLoading,
} from "@components";

import {
	ViewState,
	EditingState,
	IntegratedEditing,
	Resource,
} from "@devexpress/dx-react-scheduler";
import {
	Scheduler,
	Appointments,
	MonthView,
	WeekView,
	DateNavigator,
	ViewSwitcher,
	Toolbar,
	Resources,
	AppointmentForm,
	AppointmentTooltip,
	AllDayPanel,
	CurrentTimeIndicator,
} from "@devexpress/dx-react-scheduler-material-ui";
import axios from "axios";
import moment from "moment";

const useStyles = makeStyles((theme: Theme) => ({
	root: {
		"& > *": {
			marginBottom: theme.spacing(2),
		},
	},
}));

const SchedulePage: NextPage<SchedulePageProps> = ({
	schedules: { pagination, rows },
	resources,
}) => {
	const classes = useStyles();

	const { loading, deleteHandler } = useDelete("schedules", {
		message: () => `Schedule is deleted successfuly`,
	});

	return (
		<div className={classes.root}>
			<FilterBox
				fields={[
					{ name: "user_id", md: 2 },
					{ name: "lab_ids", md: 2 },
					{ name: "class_ids", md: 2 },
					{ name: "subject_ids", md: 2 },
					{ md: 4 },
					{ name: "start_at", md: 3, type: "date" },
					{ name: "end_at", md: 3, type: "date" },
				]}
				pagination={pagination}
			/>

			<Paper variant="outlined">
				<Scheduler data={rows} firstDayOfWeek={1}>
					<ViewState defaultCurrentViewName="Week" />
					<EditingState
						onCommitChanges={({ deleted, changed }) => {
							// @ts-ignore
							deleteHandler([deleted || Object.keys(changed)[0]]);
						}}
					/>
					<IntegratedEditing />

					<Toolbar
						{...(loading ? { rootComponent: ToolbarWithLoading } : null)}
					/>
					<MonthView />
					<WeekView cellDuration={120} />
					<ViewSwitcher />
					<DateNavigator />
					<Appointments
						appointmentContentComponent={({ data, ...rest }) => (
							<Appointments.AppointmentContent
								{...rest}
								data={data}
								style={{ flexDirection: "column" }}
							>
								<Typography variant="button">
									{data.user_id}
									<br />
									{data.lab_id}
								</Typography>
								<Typography variant="caption">
									{moment(data.startDate).format("HH:mm") +
										" - " +
										moment(data.endDate).format("HH:mm")}
								</Typography>
							</Appointments.AppointmentContent>
						)}
					/>
					<AllDayPanel />
					<Resources data={resources} mainResourceName="class_id" />
					<AppointmentTooltip showCloseButton showOpenButton showDeleteButton />
					<AppointmentForm
						overlayComponent={MyOverlay}
						layoutComponent={MyLayout}
						basicLayoutComponent={MyBasic}
					/>
					<CurrentTimeIndicator shadePreviousCells shadePreviousAppointments />
				</Scheduler>
			</Paper>
		</div>
	);
};

declare interface SchedulePageProps {
	schedules: Schedules;
	resources: Resource[];
}

export const getServerSideProps: GetServerSideProps<SchedulePageProps> = async (
	ctx
) => {
	const [schedules, { data: resources }] = await Promise.all([
		useCollection<Schedules>("/schedules", ctx.query),
		axios.get<Resource[]>("/schedules?resources"),
	]);

	return {
		props: {
			schedules,
			resources,
		},
	};
};

export default SchedulePage;
