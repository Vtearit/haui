import { useRouter } from "next/router";
import * as React from "react";
export interface IndexProps {}

const Index: React.FunctionComponent<IndexProps> = () => {
	const router = useRouter();

	React.useEffect(() => {
		router.replace("/login");
	}, []);

	return <></>;
};

export default Index;
