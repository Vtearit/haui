import * as React from "react";

import {
	makeStyles,
	Button,
	Theme,
	TextField,
	FormControlLabel,
	Checkbox,
	Grid,
	Typography,
	Table,
	TableHead,
	TableBody,
	TableCell,
	TableContainer,
	TableRow,
	Paper,
} from "@material-ui/core";

import { Controller, useForm } from "react-hook-form";
import { NextPage } from "next";
import { Link } from "@components";

const useStyles = makeStyles((theme: Theme) => ({
	root: {
		height: "100vh",
		backgroundImage: "url(/signin.jpg)",
		backgroundRepeat: "no-repeat",
		backgroundColor:
			theme.palette.type === "light"
				? theme.palette.grey[50]
				: theme.palette.grey[900],
		backgroundSize: "cover",
		backgroundPosition: "center",
	},
	right: {
		display: "flex",
		flexDirection: "column",
		justifyContent: "center",
		height: "100%",
		backgroundColor: theme.palette.background.paper,
		padding: theme.spacing(2),
	},

	action: {
		display: "flex",
		alignItems: "center",
		justifyContent: "space-between",
		margin: theme.spacing(1, 0),
	},
}));

const Login: NextPage = () => {
	const classes = useStyles();

	const { register, handleSubmit, errors, setValue, control } = useForm();

	const onSubmit = React.useCallback((data) => {
		// axios
		// 	.post("/auth/login.php", data)
		// 	.then(({ data }) => {
		// 		if (data) {
		// 			router.replace("/u");
		// 		}
		// 	})
		// 	.catch((err) => console.log(err));
		alert(JSON.stringify(data));
	}, []);

	return (
		<Grid
			container
			component="main"
			className={classes.root}
			direction="row-reverse"
			alignItems="center"
		>
			<Grid item xs={12} sm={6} md={4} className={classes.right}>
				<Typography component="h1" variant="h5" align="center" gutterBottom>
					{"Application"}
				</Typography>
				<form onSubmit={handleSubmit(onSubmit)}>
					<TextField
						inputRef={register({
							required: {
								value: true,
								message: "Email is required",
							},
							pattern: {
								value: emailPattern,

								message: "Invalid Email",
							},
						})}
						error={Boolean(errors.email)}
						helperText={errors?.email?.message || ""}
						margin="normal"
						id="email"
						label="Email"
						name="email"
						autoComplete="email"
						autoFocus
					/>
					<TextField
						inputRef={register({
							required: {
								value: true,
								message: "Password is required",
							},
							minLength: {
								value: 6,
								message: "Password must have at least 6 characters",
							},
						})}
						margin="normal"
						name="password"
						label="Password"
						type="password"
						id="password"
						autoComplete="current-password"
						error={Boolean(errors?.password)}
						helperText={errors?.password?.message || ""}
					/>
					<div className={classes.action}>
						<Controller
							name="remember"
							control={control}
							defaultValue={false}
							render={({ value, onChange }) => (
								<FormControlLabel
									control={
										<Checkbox
											onChange={(e) => onChange(e.target.checked)}
											checked={value}
											color="primary"
										/>
									}
									label="Remember me"
								/>
							)}
						/>

						<Link href="/forgot">Forgot password?</Link>
					</div>
					<Button type="submit" fullWidth variant="contained" color="primary">
						Sign In
					</Button>
				</form>
				{process.env.NODE_ENV === "development" && (
					<TableContainer
						component={Paper}
						elevation={4}
						style={{ marginTop: 16 }}
					>
						<Table size="small">
							<TableHead>
								<TableRow>
									{columns.map((col) => (
										<TableCell key={col}>{col}</TableCell>
									))}
								</TableRow>
							</TableHead>
							<TableBody>
								{rows.map((row) => (
									<TableRow
										style={{ cursor: "pointer" }}
										key={row.email}
										hover
										onClick={() => {
											setValue("email", row.email);
											setValue("password", row.password);
										}}
									>
										<TableCell>{row.email}</TableCell>
										<TableCell>{row.password}</TableCell>
										<TableCell>{row.role}</TableCell>
									</TableRow>
								))}
							</TableBody>
						</Table>
					</TableContainer>
				)}
			</Grid>
		</Grid>
	);
};

const emailPattern = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
const columns = ["Email", "Password", "Role"];
const rows = [
	{ email: "admin@email.com", password: "123456", role: "Admin" },
	{ email: "employer@email.com", password: "123456", role: "Teacher" },
	{ email: "teacher@email.com", password: "123456", role: "Employer" },
	{ email: "teacher@@@email.com", password: "123456", role: "Error" },
];

export default Login;
