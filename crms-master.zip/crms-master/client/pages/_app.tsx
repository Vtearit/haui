//@ts-nocheck
import React from "react";
import Head from "next/head";
import { AppProps } from "next/app";
import {
	ThemeProvider,
	CssBaseline,
	StylesProvider,
	Button,
} from "@material-ui/core";

import theme from "@theme";
import Layout from "@layout";
import { useRouter } from "next/router";
import "src/configs/axios";

import { SnackbarProvider } from "notistack";
import { ConfirmProvider } from "material-ui-confirm";

import { MuiPickersUtilsProvider } from "@material-ui/pickers";
import MomentUtils from "@date-io/moment";

export default function MyApp(props: AppProps) {
	const { Component, pageProps } = props;

	const { pathname } = useRouter();

	React.useEffect(() => {
		// Remove the server-side injected CSS.
		const jssStyles = document.querySelector("#jss-server-side");
		if (jssStyles) {
			jssStyles.parentNode!.removeChild(jssStyles);
		}
	}, []);

	const notistackRef = React.createRef();
	const onClickDismiss = (key: string) => () => {
		notistackRef.current.closeSnackbar(key);
	};

	return (
		<StylesProvider injectFirst>
			<Head>
				<title>My page</title>
				<meta name="viewport" content="initial-scale=1, width=device-width" />
			</Head>
			<ThemeProvider theme={theme}>
				{/* CssBaseline kickstart an elegant, consistent, and simple baseline to build upon. */}
				<CssBaseline />
				<ConfirmProvider
					defaultOptions={{
						cancellationButtonProps: {
							variant: "text",
							color: "primary",
						},
						confirmationButtonProps: {
							variant: "text",
							color: "inherit",
						},
						title: "Notification",
					}}
				>
					<SnackbarProvider
						autoHideDuration={2000}
						maxSnack={3}
						ref={notistackRef}
						action={(key) => (
							<Button
								onClick={onClickDismiss(key)}
								variant="text"
								color="inherit"
							>
								Close
							</Button>
						)}
					>
						<MuiPickersUtilsProvider utils={MomentUtils}>
							<Layout dashboard={pathname.startsWith("/u")}>
								<Component {...pageProps} />
							</Layout>
						</MuiPickersUtilsProvider>
					</SnackbarProvider>
				</ConfirmProvider>
			</ThemeProvider>
		</StylesProvider>
	);
}
